import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = '/home/z/my-project/public/images';

const STYLE = 'photorealistic, professional luxury fashion editorial photography, warm cream color palette, soft diffused natural lighting, high quality, ultra detailed, no text, no watermark';

const JOBS = [
  // ---------- Hero ----------
  { file: 'hero.png', size: '864x1152', prompt: `Elegant young South Asian woman with long dark hair, wearing a chic modest outfit in cream and blush tones, gracefully carrying a structured dusty rose leather handbag on her shoulder, standing against a warm cream seamless studio backdrop, soft golden light, gentle confident smile, luxury fashion editorial style, photorealistic, high quality, ultra detailed, no text, no watermark` },
  { file: 'hero-detail.png', size: '864x1152', prompt: `Close-up fashion editorial photograph of a young woman's torso elegantly holding a dusty rose pink structured leather handbag with gold hardware, cream linen outfit, warm beige studio background, soft natural window light, luxury magazine style, photorealistic, high quality, no text, no watermark` },

  // ---------- Collections ----------
  { file: 'col-everyday.png', size: '864x1152', prompt: `A warm taupe beige leather tote bag resting on a university library desk beside stacked notebooks, a coffee cup and a small bouquet, cozy morning light, lifestyle product photography, warm cream tones, photorealistic, high quality, no people, no text, no watermark` },
  { file: 'col-chic.png', size: '864x1152', prompt: `An elegant deep burgundy top-handle handbag on a marble dressing table with silk drapery, gold jewelry and warm candlelight bokeh in the background, evening luxury atmosphere, product photography, photorealistic, high quality, no people, no text, no watermark` },
  { file: 'col-personalized.png', size: '864x1152', prompt: `A cream ivory leather handbag with a gold letter charm and tassel hanging from its handle, surrounded by embroidery threads, small gold initials and pearls on a soft beige linen surface, customization atelier mood, warm light, photorealistic, high quality, no people, no text, no watermark` },
  { file: 'col-gift.png', size: '864x1152', prompt: `A blush pink leather handbag beautifully presented inside an open cream gift box with dusty rose silk ribbon, tissue paper and dried flowers, soft warm light, luxury gift packaging photography, photorealistic, high quality, no people, no text, no watermark` },

  // ---------- Products (front + detail views) ----------
  { file: 'product-01a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single small structured mini tote handbag in dusty blush pink pebbled leather with short top handles and delicate gold hardware, centered, standing on a warm cream seamless studio background with a soft natural shadow, ${STYLE}` },
  { file: 'product-01b.png', size: '1024x1024', prompt: `Close-up three-quarter angle detail photograph of a dusty blush pink mini tote handbag showing its gold clasp and fine pebbled leather texture, warm cream studio background, ${STYLE}` },
  { file: 'product-02a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single structured top-handle handbag in deep burgundy wine smooth leather with a gold turn-lock clasp and refined silhouette, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-02b.png', size: '1024x1024', prompt: `Close-up detail photograph of a deep burgundy top-handle handbag highlighting its gold turn-lock clasp and top handle stitching, warm cream studio background, ${STYLE}` },
  { file: 'product-03a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single spacious everyday tote bag in warm taupe beige smooth leather with long shoulder straps and minimal design, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-03b.png', size: '1024x1024', prompt: `Three-quarter angle photograph of a warm taupe beige everyday tote bag showing its interior suede lining and inner pocket, warm cream studio background, ${STYLE}` },
  { file: 'product-04a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single large soft slouchy carryall tote bag in dusty rose pink smooth leather with magnetic snap closure and shoulder handles, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-04b.png', size: '1024x1024', prompt: `Detail photograph of a dusty rose slouchy leather tote bag showing its soft folds and handle attachment, warm cream studio background, ${STYLE}` },
  { file: 'product-05a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single elegant black evening shoulder bag with a gold chain strap and satin matte finish, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-05b.png', size: '1024x1024', prompt: `Close-up photograph of an elegant black evening bag with gold chain strap detail and quilted texture, warm cream studio background, ${STYLE}` },
  { file: 'product-06a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single cream ivory leather crossbody handbag with a gold letter A initial charm hanging from the handle, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-06b.png', size: '1024x1024', prompt: `Close-up photograph of a cream leather handbag handle with a small gold initial letter charm and personalization tag, warm cream studio background, ${STYLE}` },
  { file: 'product-07a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single soft cream ivory pebbled leather tote bag with gold zipper details and a minimal luxe silhouette, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-07b.png', size: '1024x1024', prompt: `Detail photograph of a soft cream pebbled leather tote bag showing its gold zipper pull and edge stitching, warm cream studio background, ${STYLE}` },
  { file: 'product-08a.png', size: '1024x1024', prompt: `Professional e-commerce product photography of a single elegant dusty rose leather handbag displayed beside a cream gift box tied with a silk ribbon and tissue paper, centered, standing on a warm cream seamless studio background with soft shadow, ${STYLE}` },
  { file: 'product-08b.png', size: '1024x1024', prompt: `Luxury gift packaging photograph of a dusty rose handbag nestled in cream tissue paper inside an elegant gift box with silk ribbon, warm cream background, ${STYLE}` },

  // ---------- Customize banner + About ----------
  { file: 'customize-banner.png', size: '1344x768', prompt: `Wide flat-lay photograph of a handbag customization atelier: a cream leather handbag in the center surrounded by gold letter charms, colorful threads, silk ribbons, pearl beads and small tools arranged neatly on a warm beige linen surface, top-down view, warm soft light, ${STYLE}` },
  { file: 'about.png', size: '1344x768', prompt: `Warm lifestyle photograph of a bright creative studio workspace with several elegant handbags in blush, burgundy and cream arranged on a linen-covered table with dried flowers, fabric swatches and sketch books, soft daylight through sheer curtains, ${STYLE}` },

  // ---------- Instagram grid ----------
  { file: 'insta-1.png', size: '1024x1024', prompt: `Street style photograph of a young woman in a cream kurta holding a dusty rose handbag while walking through a sunlit courtyard with warm beige walls, fashion editorial, photorealistic, high quality, no text, no watermark` },
  { file: 'insta-2.png', size: '1024x1024', prompt: `Flat-lay photograph of a burgundy handbag styled with gold jewelry, sunglasses, a silk scarf and dried roses on warm cream linen fabric, top-down view, photorealistic, high quality, no text, no watermark` },
  { file: 'insta-3.png', size: '1024x1024', prompt: `Photograph of a blush pink handbag hanging on a gold hook beside a vanity mirror with warm fairy lights bokeh, cozy feminine atmosphere, photorealistic, high quality, no text, no watermark` },
  { file: 'insta-4.png', size: '1024x1024', prompt: `Photograph of elegant gift packaging: a cream box with dusty rose ribbon, a small handbag and a gift card on a beige table, warm candle light, photorealistic, high quality, no text, no watermark` },
  { file: 'insta-5.png', size: '1024x1024', prompt: `Photograph of a taupe tote bag on a university desk with pastel notebooks, a latte and wildflowers in a small vase, study aesthetic, soft daylight, photorealistic, high quality, no text, no watermark` },
  { file: 'insta-6.png', size: '1024x1024', prompt: `Color palette moodboard photograph: leather swatches in blush pink, burgundy, cream and taupe arranged in a graceful arc with gold hardware pieces and pearls on cream fabric, photorealistic, high quality, no text, no watermark` },
];

async function generate(zai, job, attempt = 1) {
  try {
    const response = await zai.images.generations.create({
      prompt: job.prompt,
      size: job.size,
    });
    const b64 = response?.data?.[0]?.base64;
    if (!b64) throw new Error('empty base64 in response');
    const buffer = Buffer.from(b64, 'base64');
    if (buffer.length < 5000) throw new Error(`suspiciously small file (${buffer.length} bytes)`);
    fs.writeFileSync(path.join(OUT_DIR, job.file), buffer);
    console.log(`OK  ${job.file}  (${Math.round(buffer.length / 1024)} KB)`);
    return true;
  } catch (err) {
    console.error(`ERR ${job.file} attempt ${attempt}: ${err.message}`);
    if (attempt < 3) {
      await new Promise((r) => setTimeout(r, 2500 * attempt));
      return generate(zai, job, attempt + 1);
    }
    return false;
  }
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const zai = await ZAI.create();

  // Skip files that already exist (idempotent re-runs)
  const pending = JOBS.filter((j) => {
    const p = path.join(OUT_DIR, j.file);
    if (fs.existsSync(p) && fs.statSync(p).size > 5000) {
      console.log(`SKIP ${j.file} (exists)`);
      return false;
    }
    return true;
  });

  const CONCURRENCY = 3;
  let index = 0;
  let failed = 0;

  async function worker() {
    while (index < pending.length) {
      const job = pending[index++];
      const ok = await generate(zai, job);
      if (!ok) failed++;
    }
  }

  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`\nDone. ${pending.length - failed}/${pending.length} generated, ${failed} failed.`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error('FATAL', e);
  process.exit(1);
});
