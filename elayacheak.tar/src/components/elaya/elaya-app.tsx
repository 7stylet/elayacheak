"use client";

import { useEffect } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useELAYA, hashToRoute } from "@/lib/store";
import { Navbar } from "@/components/elaya/navbar";
import { Footer } from "@/components/elaya/footer";
import { CartDrawer } from "@/components/elaya/cart-drawer";
import { SearchOverlay } from "@/components/elaya/search-overlay";
import { HomeView } from "@/components/elaya/views/home-view";
import { ShopView } from "@/components/elaya/views/shop-view";
import { ProductView } from "@/components/elaya/views/product-view";
import { CustomizeView } from "@/components/elaya/views/customize-view";
import { CartView } from "@/components/elaya/views/cart-view";
import { CheckoutView } from "@/components/elaya/views/checkout-view";
import { OrderSuccessView } from "@/components/elaya/views/order-success-view";
import { WishlistView } from "@/components/elaya/views/wishlist-view";
import { AboutView } from "@/components/elaya/views/about-view";
import { ContactView } from "@/components/elaya/views/contact-view";
import { FaqView } from "@/components/elaya/views/faq-view";
import { PolicyView } from "@/components/elaya/views/policy-view";

const POLICY_VIEWS: Record<string, "shipping" | "returns" | "privacy" | "terms"> = {
  shipping: "shipping",
  returns: "returns",
  privacy: "privacy",
  terms: "terms",
};

export function ELAYAApp() {
  const route = useELAYA((s) => s.route);
  const searchOpen = useELAYA((s) => s.searchOpen);
  const syncFromHash = useELAYA((s) => s.syncFromHash);
  const reduce = useReducedMotion();

  // Initial hash sync + browser back/forward support
  useEffect(() => {
    syncFromHash();
    const onPop = () => {
      const r = hashToRoute(window.location.hash);
      useELAYA.setState({ route: r, menuOpen: false, searchOpen: false });
      window.scrollTo({ top: 0, behavior: "auto" });
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [syncFromHash]);

  const key = `${route.view}:${route.slug ?? ""}:${route.collection ?? ""}`;

  const renderView = () => {
    switch (route.view) {
      case "home":
        return <HomeView />;
      case "shop":
        return <ShopView key={key} />;
      case "product":
        return <ProductView slug={route.slug} />;
      case "customize":
        return <CustomizeView />;
      case "cart":
        return <CartView />;
      case "checkout":
        return <CheckoutView />;
      case "order-success":
        return <OrderSuccessView />;
      case "wishlist":
        return <WishlistView />;
      case "about":
        return <AboutView />;
      case "contact":
        return <ContactView />;
      case "faq":
        return <FaqView />;
      case "shipping":
      case "returns":
      case "privacy":
      case "terms":
        return <PolicyView policy={POLICY_VIEWS[route.view]} />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={key}
            initial={reduce ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduce ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
      <CartDrawer />
      {searchOpen && <SearchOverlay />}
    </div>
  );
}
