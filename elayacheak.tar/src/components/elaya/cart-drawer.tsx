"use client";

import Image from "next/image";
import { Minus, Plus, ShoppingBag, Trash2, X } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { useELAYA, cartSubtotal, deliveryFeeFor } from "@/lib/store";
import { SITE_CONFIG, formatPKR } from "@/lib/config";

export function CartDrawer() {
  const cartOpen = useELAYA((s) => s.cartOpen);
  const setCartOpen = useELAYA((s) => s.setCartOpen);
  const cart = useELAYA((s) => s.cart);
  const setQty = useELAYA((s) => s.setQty);
  const removeFromCart = useELAYA((s) => s.removeFromCart);
  const navigate = useELAYA((s) => s.navigate);

  const subtotal = cartSubtotal(cart);
  const delivery = deliveryFeeFor(subtotal);
  const remainingForFree = SITE_CONFIG.freeDeliveryThreshold - subtotal;

  const goCheckout = () => {
    setCartOpen(false);
    navigate({ view: "checkout" });
  };

  return (
    <Sheet open={cartOpen} onOpenChange={setCartOpen}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-0 border-border bg-cream p-0 sm:max-w-md"
      >
        <SheetHeader className="border-b border-border px-5 py-4">
          <SheetTitle className="flex items-center gap-2 font-serif text-xl text-charcoal">
            <ShoppingBag className="h-4 w-4 text-burgundy" aria-hidden />
            Your Bag ({cart.length})
          </SheetTitle>
          <SheetDescription className="sr-only">
            Review the items in your shopping bag, adjust quantities and
            proceed to checkout.
          </SheetDescription>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-beige-soft">
              <ShoppingBag className="h-8 w-8 text-rose-dust" aria-hidden />
            </div>
            <p className="font-serif text-xl text-charcoal">Your bag is empty</p>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Beautiful things are waiting. Explore the collection and find the
              bag that feels like you.
            </p>
            <button
              type="button"
              onClick={() => {
                setCartOpen(false);
                navigate({ view: "shop" });
              }}
              className="mt-2 rounded-full bg-burgundy px-7 py-3 text-xs font-medium uppercase tracking-[0.18em] text-primary-foreground transition-colors hover:bg-burgundy-deep"
            >
              Shop Collection
            </button>
          </div>
        ) : (
          <>
            {/* Free delivery progress */}
            {remainingForFree > 0 ? (
              <div className="border-b border-border bg-blush/50 px-5 py-3">
                <p className="text-xs text-charcoal/80">
                  Add <strong>{formatPKR(remainingForFree)}</strong> more for free
                  delivery
                </p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-rose-dust to-burgundy transition-all duration-500"
                    style={{
                      width: `${Math.min(100, (subtotal / SITE_CONFIG.freeDeliveryThreshold) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            ) : (
              <div className="border-b border-border bg-blush/50 px-5 py-3">
                <p className="text-xs font-medium text-burgundy">
                  You have unlocked free delivery
                </p>
              </div>
            )}

            {/* Items */}
            <div className="scrollbar-thin flex-1 overflow-y-auto px-5 py-4">
              <ul className="space-y-5">
                {cart.map((item) => (
                  <li key={item.key} className="flex gap-4">
                    <div className="relative h-24 w-20 shrink-0 overflow-hidden rounded-xl bg-beige-soft">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        sizes="80px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-serif text-[15px] leading-snug text-charcoal">
                            {item.name}
                          </p>
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            {item.color}
                            {item.customization?.initials
                              ? ` · "${item.customization.initials}"`
                              : ""}
                          </p>
                        </div>
                        <button
                          type="button"
                          aria-label={`Remove ${item.name} from cart`}
                          onClick={() => removeFromCart(item.key)}
                          className="text-muted-foreground transition-colors hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" aria-hidden />
                        </button>
                      </div>

                      {item.customization && (
                        <p className="mt-1 line-clamp-2 rounded-md bg-secondary/70 px-2 py-1 text-[11px] leading-relaxed text-charcoal/70">
                          Custom: {[item.customization.styleName, ...item.customization.decor].filter(Boolean).join(" · ")}
                        </p>
                      )}

                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center rounded-full border border-input bg-white">
                          <button
                            type="button"
                            aria-label="Decrease quantity"
                            onClick={() => setQty(item.key, item.qty - 1)}
                            className="flex h-8 w-8 items-center justify-center rounded-full text-charcoal hover:text-burgundy"
                          >
                            <Minus className="h-3.5 w-3.5" aria-hidden />
                          </button>
                          <span className="w-6 text-center text-sm font-medium" aria-live="polite">
                            {item.qty}
                          </span>
                          <button
                            type="button"
                            aria-label="Increase quantity"
                            onClick={() => setQty(item.key, item.qty + 1)}
                            className="flex h-8 w-8 items-center justify-center rounded-full text-charcoal hover:text-burgundy"
                          >
                            <Plus className="h-3.5 w-3.5" aria-hidden />
                          </button>
                        </div>
                        <p className="text-[15px] font-medium text-burgundy">
                          {formatPKR(item.unitPrice * item.qty)}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            {/* Summary */}
            <div className="border-t border-border bg-white/60 px-5 py-4">
              <div className="flex items-center justify-between text-sm text-charcoal/80">
                <span>Subtotal</span>
                <span>{formatPKR(subtotal)}</span>
              </div>
              <div className="mt-1 flex items-center justify-between text-sm text-charcoal/80">
                <span>Delivery</span>
                <span>{delivery === 0 ? "Free" : formatPKR(delivery)}</span>
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-dashed border-border pt-2">
                <span className="text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal">
                  Total
                </span>
                <span className="font-serif text-xl text-burgundy">
                  {formatPKR(subtotal + delivery)}
                </span>
              </div>
              <button
                type="button"
                onClick={goCheckout}
                className="mt-4 w-full rounded-full bg-burgundy py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:bg-burgundy-deep hover:shadow-lg"
              >
                Proceed to Checkout
              </button>
              <button
                type="button"
                onClick={() => {
                  setCartOpen(false);
                  navigate({ view: "cart" });
                }}
                className="mt-2 w-full rounded-full border border-burgundy/30 py-3 text-xs font-medium uppercase tracking-[0.18em] text-burgundy transition-colors hover:bg-secondary"
              >
                View Bag
              </button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
