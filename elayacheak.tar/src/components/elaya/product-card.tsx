"use client";

import Image from "next/image";
import { Heart, ShoppingBag } from "lucide-react";
import { Product, formatPKRDisplay } from "@/lib/product-utils";
import { useELAYA } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const navigate = useELAYA((s) => s.navigate);
  const wishlist = useELAYA((s) => s.wishlist);
  const toggleWishlist = useELAYA((s) => s.toggleWishlist);
  const addToCart = useELAYA((s) => s.addToCart);
  const setCartOpen = useELAYA((s) => s.setCartOpen);

  const wishlisted = wishlist.includes(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      name: product.name,
      image: product.images[0],
      unitPrice: product.price + (product.colors[0]?.priceDelta ?? 0),
      color: product.colors[0]?.name ?? "As shown",
      qty: 1,
    });
    setCartOpen(true);
    toast({
      title: "Added to cart",
      description: `${product.name} is waiting for you.`,
    });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
    toast({
      title: wishlisted ? "Removed from wishlist" : "Saved to wishlist",
      description: product.name,
    });
  };

  return (
    <article
      role="link"
      tabIndex={0}
      aria-label={`View ${product.name}`}
      onClick={() => navigate({ view: "product", slug: product.slug })}
      onKeyDown={(e) => {
        if (e.key === "Enter") navigate({ view: "product", slug: product.slug });
      }}
      className="group cursor-pointer focus-visible:outline-2 focus-visible:outline-burgundy"
    >
      {/* Image */}
      <div className="relative overflow-hidden rounded-2xl bg-beige-soft/60 shadow-[0_2px_16px_rgba(104,45,59,0.06)] transition-shadow duration-500 group-hover:shadow-[0_14px_38px_rgba(104,45,59,0.14)]">
        <div className="relative aspect-square">
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="zoom-img object-cover"
            priority={priority}
          />
          {/* second image cross-fade on hover */}
          {product.images[1] && (
            <Image
              src={product.images[1]}
              alt=""
              fill
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              className="object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
            />
          )}
        </div>

        {/* Badge */}
        {product.badge && (
          <Badge
            className={cn(
              "absolute left-3 top-3 rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] shadow-sm",
              product.badge === "New Arrival"
                ? "bg-burgundy text-primary-foreground"
                : "bg-white/90 text-burgundy border border-rose-dust/60"
            )}
          >
            {product.badge}
          </Badge>
        )}
        {!product.inStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-cream/70">
            <span className="rounded-full bg-charcoal/85 px-4 py-2 text-xs uppercase tracking-[0.2em] text-cream">
              Out of stock
            </span>
          </div>
        )}

        {/* Wishlist */}
        <button
          type="button"
          aria-label={wishlisted ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
          aria-pressed={wishlisted}
          onClick={handleWishlist}
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-burgundy shadow-sm backdrop-blur transition-all duration-300 hover:scale-110 hover:bg-white focus-visible:outline-2 focus-visible:outline-burgundy"
        >
          <Heart
            className={cn("h-4 w-4 transition-colors", wishlisted && "fill-burgundy text-burgundy")}
          />
        </button>

        {/* Quick add — slides up on hover (always visible on touch) */}
        <div className="absolute inset-x-3 bottom-3 translate-y-2 opacity-100 transition-all duration-500 md:translate-y-4 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100">
          <button
            type="button"
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-charcoal/90 px-4 py-2.5 text-[12px] font-medium uppercase tracking-[0.16em] text-cream backdrop-blur transition-colors hover:bg-burgundy disabled:cursor-not-allowed disabled:opacity-50"
          >
            <ShoppingBag className="h-3.5 w-3.5" aria-hidden />
            Add to Cart
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="pt-4 text-center">
        <h3 className="font-serif text-[17px] leading-snug text-charcoal">
          {product.name}
        </h3>
        <div className="mt-1.5 flex items-center justify-center gap-2">
          <span className="text-[15px] font-medium text-burgundy">
            {formatPKRDisplay(product.price)}
          </span>
          {product.compareAtPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPKRDisplay(product.compareAtPrice)}
            </span>
          )}
        </div>
        {/* Colour swatches */}
        <div className="mt-2.5 flex items-center justify-center gap-1.5" aria-label="Available colours">
          {product.colors.map((c) => (
            <span
              key={c.name}
              title={c.name}
              className="h-3.5 w-3.5 rounded-full border border-black/10 shadow-[inset_0_0_2px_rgba(0,0,0,0.1)]"
              style={{ backgroundColor: c.hex }}
            />
          ))}
        </div>
        <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed text-muted-foreground hidden md:block">
          {product.shortDescription}
        </p>
      </div>
    </article>
  );
}
