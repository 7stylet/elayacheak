"use client";

import Image from "next/image";
import { ArrowRight, Gem, GraduationCap, HeartHandshake, Leaf } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { Reveal } from "@/components/elaya/reveal";

const VALUES = [
  {
    icon: HeartHandshake,
    title: "You first, always",
    text: "Every design starts with real questions: what does a student carry on a Tuesday? What makes a gift feel personal? Your answers shape our bags.",
  },
  {
    icon: Gem,
    title: "Quality without the markup",
    text: "We keep our prices honest by focusing our budget on materials and finishing — not on luxury-brand markups. Boutique feel, student-friendly price.",
  },
  {
    icon: Leaf,
    title: "Thoughtful materials",
    text: "Our bags use carefully selected vegan leathers and hardware chosen to handle daily life gracefully, with care guidance so they last longer.",
  },
  {
    icon: GraduationCap,
    title: "Made for your calendar",
    text: "From 8am lectures to mehndi nights, our collections follow the real rhythm of your week — practical when you need it, elegant when it matters.",
  },
];

export function AboutView() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <div className="bg-cream pb-20">
      {/* Header */}
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center sm:px-6 md:py-16 lg:px-8">
          <p className="eyebrow text-burgundy/70">About ELAYA</p>
          <h1 className="display-1 mt-4 text-charcoal text-balance">
            Every Bag Has a Story.
            <br />
            <span className="italic text-burgundy">Yours Starts Here.</span>
          </h1>
        </div>
      </div>

      {/* Story */}
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        <Reveal className="relative order-2 lg:order-1">
          <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem] shadow-[0_24px_60px_rgba(104,45,59,0.14)]">
            <Image
              src="/images/about.png"
              alt="The ELAYA studio — handbags, swatches and dried flowers in warm daylight"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <div className="absolute -bottom-6 left-6 rounded-2xl bg-burgundy px-6 py-5 text-cream shadow-xl">
            <p className="font-serif text-[15px] italic">
              “Carry Your Style. Express Your Story.”
            </p>
          </div>
        </Reveal>

        <div className="order-1 lg:order-2">
          <Reveal>
            <div className="space-y-6 text-[15px] leading-relaxed text-muted-foreground">
              <p>
                ELAYA was created with a simple idea: a handbag should be more
                than something you carry. It should reflect your personality,
                complement your style, and accompany you through life&apos;s
                everyday moments.
              </p>
              <p>
                We noticed that the bags available to young women in Pakistan
                sat at two extremes — either mass-produced and forgettable, or
                imported and far beyond a student budget. ELAYA lives in the
                space between: thoughtful design, honest materials, and prices
                that respect where you are in life.
              </p>
              <p>
                From practical everyday bags to thoughtful personalized designs,
                we believe every woman deserves something that feels uniquely
                hers. That&apos;s why customization isn&apos;t a side feature
                for us — it&apos;s at the heart of what we do.
              </p>
              <p className="font-serif text-lg italic text-charcoal">
                At ELAYA, your style inspires our designs, and your story makes
                them special.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => navigate({ view: "shop" })}
                className="group inline-flex items-center gap-3 rounded-full bg-burgundy px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all hover:bg-burgundy-deep hover:shadow-lg"
              >
                Explore the Collection
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
              </button>
              <button
                type="button"
                onClick={() => navigate({ view: "customize" })}
                className="rounded-full border border-burgundy/35 px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy transition-all hover:bg-secondary"
              >
                Design Your Own
              </button>
            </div>
          </Reveal>
        </div>
      </div>

      {/* Values */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center">
          <p className="eyebrow text-burgundy/70">What We Believe</p>
          <h2 className="display-2 mt-3 text-charcoal">The Ideas Behind Every Stitch</h2>
        </Reveal>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:gap-6">
          {VALUES.map((v, i) => (
            <Reveal key={v.title} delay={i * 0.07}>
              <article className="h-full rounded-3xl border border-border/70 bg-white p-8 shadow-[0_4px_20px_rgba(104,45,59,0.05)] transition-shadow hover:shadow-[0_16px_44px_rgba(104,45,59,0.12)]">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blush text-burgundy">
                  <v.icon className="h-5.5 w-5.5" aria-hidden />
                </span>
                <h3 className="mt-5 font-serif text-xl text-charcoal">{v.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {v.text}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
