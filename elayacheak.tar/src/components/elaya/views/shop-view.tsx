"use client";

import { useMemo, useState } from "react";
import { ChevronDown, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Slider } from "@/components/ui/slider";
import { useELAYA } from "@/lib/store";
import {
  ALL_COLORS,
  ALL_STYLES,
  COLLECTIONS,
  PRODUCTS,
} from "@/lib/products";
import { formatPKR } from "@/lib/config";
import { ProductCard } from "@/components/elaya/product-card";
import { cn } from "@/lib/utils";

type SortKey = "featured" | "price-asc" | "price-desc" | "newest";

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "newest", label: "Newest Arrivals" },
];

const PRICE_MIN = 0;
const PRICE_MAX = 6000;

const COLOR_HEX: Record<string, string> = {
  "Blush Pink": "#E8C4BE",
  "Dusty Rose": "#D9A6A0",
  Burgundy: "#682D3B",
  Black: "#2B2626",
  Cream: "#F1E7DA",
  Taupe: "#B9A48E",
  Sage: "#A8B5A2",
};

interface Filters {
  price: [number, number];
  colors: string[];
  styles: string[];
  collections: string[];
  inStockOnly: boolean;
}

export function ShopView() {
  const route = useELAYA((s) => s.route);
  const initialCollection =
    route.collection && route.collection !== "new" ? route.collection : undefined;

  const [filters, setFilters] = useState<Filters>({
    price: [PRICE_MIN, PRICE_MAX],
    colors: [],
    styles: [],
    collections: initialCollection ? [initialCollection] : [],
    inStockOnly: false,
  });
  const [sort, setSort] = useState<SortKey>(route.collection === "new" ? "newest" : "featured");
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const update = (patch: Partial<Filters>) =>
    setFilters((f) => ({ ...f, ...patch }));

  const toggleIn = (list: string[], value: string) =>
    list.includes(value) ? list.filter((v) => v !== value) : [...list, value];

  const activeFilterCount =
    filters.colors.length +
    filters.styles.length +
    filters.collections.length +
    (filters.inStockOnly ? 1 : 0) +
    (filters.price[0] !== PRICE_MIN || filters.price[1] !== PRICE_MAX ? 1 : 0);

  const clearFilters = () =>
    setFilters({
      price: [PRICE_MIN, PRICE_MAX],
      colors: [],
      styles: [],
      collections: [],
      inStockOnly: false,
    });

  const filtered = useMemo(() => {
    let list = PRODUCTS.filter((p) => {
      if (p.price < filters.price[0] || p.price > filters.price[1]) return false;
      if (filters.inStockOnly && !p.inStock) return false;
      if (
        filters.collections.length > 0 &&
        !filters.collections.includes(p.collection)
      )
        return false;
      if (filters.styles.length > 0 && !filters.styles.includes(p.style))
        return false;
      if (
        filters.colors.length > 0 &&
        !p.colors.some((c) => filters.colors.includes(c.name))
      )
        return false;
      return true;
    });

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "newest":
        list = [...list].sort(
          (a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime()
        );
        break;
      default:
        list = [...list].sort((a, b) => a.featuredRank - b.featuredRank);
    }
    return list;
  }, [filters, sort]);

  const FilterPanel = (
    <div className="space-y-8">
      {/* Availability */}
      <div>
        <p className="eyebrow mb-3 text-charcoal">Availability</p>
        <div className="flex items-center gap-2.5">
          <Checkbox
            id="in-stock"
            checked={filters.inStockOnly}
            onCheckedChange={(v) => update({ inStockOnly: v === true })}
          />
          <Label htmlFor="in-stock" className="cursor-pointer text-sm text-charcoal/80">
            In stock only
          </Label>
        </div>
      </div>

      {/* Price */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <p className="eyebrow text-charcoal">Price Range</p>
          <p className="text-xs text-muted-foreground">
            {formatPKR(filters.price[0])} — {formatPKR(filters.price[1])}
          </p>
        </div>
        <Slider
          min={PRICE_MIN}
          max={PRICE_MAX}
          step={250}
          value={filters.price}
          onValueChange={(v) => update({ price: v as [number, number] })}
          aria-label="Price range"
        />
        <div className="mt-1.5 flex justify-between text-[11px] text-muted-foreground">
          <span>{formatPKR(PRICE_MIN)}</span>
          <span>{formatPKR(PRICE_MAX)}+</span>
        </div>
      </div>

      {/* Collection */}
      <div>
        <p className="eyebrow mb-3 text-charcoal">Collection</p>
        <ul className="space-y-2.5">
          {COLLECTIONS.map((c) => (
            <li key={c.id} className="flex items-center gap-2.5">
              <Checkbox
                id={`col-${c.id}`}
                checked={filters.collections.includes(c.id)}
                onCheckedChange={() =>
                  update({ collections: toggleIn(filters.collections, c.id) })
                }
              />
              <Label htmlFor={`col-${c.id}`} className="cursor-pointer text-sm text-charcoal/80">
                {c.name}
              </Label>
            </li>
          ))}
        </ul>
      </div>

      {/* Style */}
      <div>
        <p className="eyebrow mb-3 text-charcoal">Style</p>
        <ul className="space-y-2.5">
          {ALL_STYLES.map((s) => (
            <li key={s} className="flex items-center gap-2.5">
              <Checkbox
                id={`style-${s}`}
                checked={filters.styles.includes(s)}
                onCheckedChange={() => update({ styles: toggleIn(filters.styles, s) })}
              />
              <Label htmlFor={`style-${s}`} className="cursor-pointer text-sm text-charcoal/80">
                {s}
              </Label>
            </li>
          ))}
        </ul>
      </div>

      {/* Colour */}
      <div>
        <p className="eyebrow mb-3 text-charcoal">Colour</p>
        <div className="flex flex-wrap gap-2">
          {ALL_COLORS.map((c) => {
            const active = filters.colors.includes(c);
            return (
              <button
                key={c}
                type="button"
                role="checkbox"
                aria-checked={active}
                aria-label={c}
                onClick={() => update({ colors: toggleIn(filters.colors, c) })}
                className={cn(
                  "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition-all",
                  active
                    ? "border-burgundy bg-burgundy text-primary-foreground"
                    : "border-border bg-white text-charcoal/80 hover:border-rose-dust"
                )}
              >
                <span
                  className="h-3 w-3 rounded-full border border-black/10"
                  style={{ backgroundColor: COLOR_HEX[c] ?? "#ccc" }}
                />
                {c}
              </button>
            );
          })}
        </div>
      </div>

      {activeFilterCount > 0 && (
        <Button
          variant="outline"
          onClick={clearFilters}
          className="w-full rounded-full border-burgundy/30 text-burgundy hover:bg-secondary"
        >
          <X className="mr-1 h-3.5 w-3.5" aria-hidden />
          Clear all filters ({activeFilterCount})
        </Button>
      )}
    </div>
  );

  return (
    <div className="bg-cream">
      {/* Page header */}
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6 md:py-14 lg:px-8">
          <p className="eyebrow text-burgundy/70">The ELAYA Wardrobe</p>
          <h1 className="display-2 mt-3 text-charcoal">Shop All Bags</h1>
          <p className="mx-auto mt-3 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
            Every silhouette in one place — filter by price, colour, style and
            collection to find the one that feels like you.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-[260px_1fr] lg:gap-10">
          {/* Desktop filters */}
          <aside className="hidden lg:block">
            <div className="sticky top-28 max-h-[calc(100vh-8rem)] overflow-y-auto pr-2 scrollbar-thin">
              {FilterPanel}
            </div>
          </aside>

          {/* Products */}
          <div>
            <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground" aria-live="polite">
                {filtered.length} {filtered.length === 1 ? "bag" : "bags"}
                {activeFilterCount > 0 && " matching your filters"}
              </p>

              <div className="flex items-center gap-3">
                {/* Mobile filter trigger */}
                <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                  <SheetTrigger asChild>
                    <Button
                      variant="outline"
                      className="rounded-full border-burgundy/30 text-burgundy lg:hidden"
                    >
                      <SlidersHorizontal className="mr-1.5 h-4 w-4" aria-hidden />
                      Filters
                      {activeFilterCount > 0 && (
                        <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-burgundy text-[10px] text-white">
                          {activeFilterCount}
                        </span>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[86%] max-w-sm overflow-y-auto bg-cream">
                    <SheetHeader>
                      <SheetTitle className="font-serif text-xl text-charcoal">
                        Filters
                      </SheetTitle>
                      <SheetDescription className="sr-only">
                        Filter bags by availability, price, collection, style
                        and colour.
                      </SheetDescription>
                    </SheetHeader>
                    <div className="px-4 pb-8">{FilterPanel}</div>
                  </SheetContent>
                </Sheet>

                {/* Sort */}
                <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
                  <SelectTrigger
                    aria-label="Sort products"
                    className="w-[200px] rounded-full border-border bg-white text-[13px]"
                  >
                    <span className="flex items-center gap-2">
                      <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" aria-hidden />
                      <SelectValue />
                    </span>
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {SORT_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="flex flex-col items-center rounded-3xl border border-dashed border-border bg-white/60 px-6 py-20 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-blush">
                  <X className="h-7 w-7 text-burgundy" aria-hidden />
                </span>
                <p className="mt-5 font-serif text-2xl text-charcoal">
                  No bags match those filters
                </p>
                <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
                  Try widening the price range or removing a colour or style
                  filter — your perfect bag might be one filter away.
                </p>
                <Button
                  onClick={clearFilters}
                  className="mt-6 rounded-full bg-burgundy px-7 py-3 text-xs uppercase tracking-[0.18em] hover:bg-burgundy-deep"
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 md:gap-x-6">
                {filtered.map((p, i) => (
                  <ProductCard key={p.id} product={p} priority={i < 3} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
