"use client";

import { useState } from "react";
import {
  Clock,
  Instagram,
  Loader2,
  Mail,
  MapPin,
  MessageCircle,
  Send,
} from "lucide-react";
import { SITE_CONFIG, whatsappLink } from "@/lib/config";
import { cn } from "@/lib/utils";
import { Reveal } from "@/components/elaya/reveal";

export function ContactView() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Partial<Record<"name" | "email" | "message", string>>>({});
  const [status, setStatus] = useState<"idle" | "loading" | "sent" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  const set = (key: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    if (errors[key]) setErrors((er) => ({ ...er, [key]: undefined }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: typeof errors = {};
    if (form.name.trim().length < 2) errs.name = "Please tell us your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim()))
      errs.email = "Please enter a valid email so we can reply.";
    if (form.message.trim().length < 10)
      errs.message = "Please write at least a short message (10+ characters).";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setStatus("loading");
    setFeedback("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          email: form.email.trim(),
          message: form.message.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatus("error");
        setFeedback(data?.error ?? "Message could not be sent — please try again.");
        return;
      }
      setStatus("sent");
      setFeedback("Message received — we'll reply to your email within 24 hours, Insha'Allah.");
      setForm({ name: "", email: "", message: "" });
    } catch {
      setStatus("error");
      setFeedback("Network error — please check your connection and try again.");
    }
  };

  const inputCls = (key: keyof typeof form) =>
    cn(
      "w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground/50 focus:shadow-[0_0_0_4px_rgba(217,166,160,0.18)]",
      errors[key] ? "border-destructive" : "border-input focus:border-rose-dust"
    );

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center sm:px-6 md:py-14 lg:px-8">
          <p className="eyebrow text-burgundy/70">We&apos;d Love to Hear From You</p>
          <h1 className="display-2 mt-3 text-charcoal">Contact ELAYA</h1>
          <p className="mx-auto mt-3 max-w-lg text-[15px] leading-relaxed text-muted-foreground">
            Questions about a bag, your order, or a custom design? Send us a
            message — real humans reply here.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-14">
          {/* Form */}
          <Reveal>
            <section
              aria-labelledby="contact-form-heading"
              className="rounded-3xl border border-border bg-white p-6 shadow-[0_4px_24px_rgba(104,45,59,0.05)] md:p-8"
            >
              <h2 id="contact-form-heading" className="font-serif text-xl text-charcoal">
                Send us a message
              </h2>
              <form onSubmit={submit} noValidate className="mt-6 space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="ct-name" className="mb-2 block text-[13px] font-medium text-charcoal">
                      Your name *
                    </label>
                    <input
                      id="ct-name"
                      type="text"
                      value={form.name}
                      onChange={set("name")}
                      placeholder="Ayesha Khan"
                      autoComplete="name"
                      className={inputCls("name")}
                      aria-invalid={!!errors.name}
                    />
                    {errors.name && (
                      <p role="alert" className="mt-1.5 text-xs text-destructive">{errors.name}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="ct-email" className="mb-2 block text-[13px] font-medium text-charcoal">
                      Email *
                    </label>
                    <input
                      id="ct-email"
                      type="email"
                      value={form.email}
                      onChange={set("email")}
                      placeholder="you@example.com"
                      autoComplete="email"
                      className={inputCls("email")}
                      aria-invalid={!!errors.email}
                    />
                    {errors.email && (
                      <p role="alert" className="mt-1.5 text-xs text-destructive">{errors.email}</p>
                    )}
                  </div>
                </div>
                <div>
                  <label htmlFor="ct-message" className="mb-2 block text-[13px] font-medium text-charcoal">
                    Message *
                  </label>
                  <textarea
                    id="ct-message"
                    rows={5}
                    value={form.message}
                    onChange={set("message")}
                    placeholder="How can we help?"
                    className={cn(inputCls("message"), "resize-none")}
                    aria-invalid={!!errors.message}
                  />
                  {errors.message && (
                    <p role="alert" className="mt-1.5 text-xs text-destructive">{errors.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={status === "loading"}
                  className="flex items-center gap-2.5 rounded-full bg-burgundy px-9 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all hover:bg-burgundy-deep hover:shadow-lg disabled:opacity-60"
                >
                  {status === "loading" ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" aria-hidden />
                      Send Message
                    </>
                  )}
                </button>

                {status === "sent" && (
                  <p role="status" className="rounded-xl bg-sage/15 px-4 py-3 text-sm text-charcoal">
                    {feedback}
                  </p>
                )}
                {status === "error" && (
                  <p role="alert" className="rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">
                    {feedback}
                  </p>
                )}
              </form>
            </section>
          </Reveal>

          {/* Info cards */}
          <div className="space-y-4">
            <Reveal delay={0.08}>
              <div className="rounded-3xl border border-border bg-white p-6">
                <p className="eyebrow mb-4 text-burgundy/70">Reach us directly</p>
                <ul className="space-y-4 text-sm">
                  <li className="flex items-start gap-3">
                    <Mail className="mt-0.5 h-4 w-4 shrink-0 text-burgundy" aria-hidden />
                    <span>
                      <span className="block font-medium text-charcoal">Email</span>
                      <a
                        href={`mailto:${SITE_CONFIG.email}`}
                        className="text-muted-foreground hover:text-burgundy"
                      >
                        {SITE_CONFIG.email}
                      </a>
                      <span className="mt-0.5 block text-[11px] text-muted-foreground">
                        (placeholder — replace in site configuration)
                      </span>
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Clock className="mt-0.5 h-4 w-4 shrink-0 text-burgundy" aria-hidden />
                    <span>
                      <span className="block font-medium text-charcoal">Reply time</span>
                      <span className="text-muted-foreground">
                        Within 24 hours, 7 days a week
                      </span>
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-burgundy" aria-hidden />
                    <span>
                      <span className="block font-medium text-charcoal">Delivery</span>
                      <span className="text-muted-foreground">
                        We deliver across Pakistan
                      </span>
                    </span>
                  </li>
                </ul>

                {SITE_CONFIG.whatsappNumber ? (
                  <a
                    href={whatsappLink("Assalam-o-Alaikum ELAYA! I have a question.")}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-5 flex items-center justify-center gap-2 rounded-full bg-sage py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-white transition-colors hover:bg-sage/85"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden />
                    Chat on WhatsApp
                  </a>
                ) : (
                  <p className="mt-5 flex items-center gap-2 rounded-xl border border-dashed border-border px-4 py-3 text-[12px] text-muted-foreground">
                    <MessageCircle className="h-4 w-4 shrink-0" aria-hidden />
                    WhatsApp support will appear here once the store adds its
                    number in the site configuration.
                  </p>
                )}

                {SITE_CONFIG.instagramUrl ? (
                  <a
                    href={SITE_CONFIG.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 flex items-center justify-center gap-2 rounded-full border border-burgundy/30 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-burgundy hover:bg-secondary"
                  >
                    <Instagram className="h-4 w-4" aria-hidden />
                    Follow on Instagram
                  </a>
                ) : (
                  <p className="mt-3 flex items-center gap-2 rounded-xl border border-dashed border-border px-4 py-3 text-[12px] text-muted-foreground">
                    <Instagram className="h-4 w-4 shrink-0" aria-hidden />
                    Instagram — coming soon
                  </p>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </div>
  );
}
