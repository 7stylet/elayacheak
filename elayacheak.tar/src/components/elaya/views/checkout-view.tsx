"use client";

import { useState } from "react";
import {
  Banknote,
  Building2,
  ChevronRight,
  Copy,
  Loader2,
  Lock,
  MessageCircle,
  ShieldCheck,
} from "lucide-react";
import { useELAYA, cartSubtotal, deliveryFeeFor, CartItem } from "@/lib/store";
import { SITE_CONFIG, formatPKR, whatsappLink } from "@/lib/config";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

interface FormState {
  name: string;
  phone: string;
  email: string;
  city: string;
  address: string;
  notes: string;
}

type PaymentMethod = "cod" | "bank_transfer";

const INITIAL_FORM: FormState = {
  name: "",
  phone: "",
  email: "",
  city: "",
  address: "",
  notes: "",
};

function validate(form: FormState): Partial<Record<keyof FormState, string>> {
  const errors: Partial<Record<keyof FormState, string>> = {};
  if (form.name.trim().length < 3) errors.name = "Please enter your full name.";
  if (!/^(\+?92|0)?[0-9]{10}$/.test(form.phone.replace(/[\s-]/g, "")))
    errors.phone = "Enter a valid Pakistani phone number (e.g. 03001234567).";
  if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim()))
    errors.email = "That email address doesn't look right.";
  if (form.city.trim().length < 2) errors.city = "Please enter your city.";
  if (form.address.trim().length < 10)
    errors.address = "Please enter your complete delivery address (house, street, area).";
  return errors;
}

export function CheckoutView() {
  const cart = useELAYA((s) => s.cart);
  const navigate = useELAYA((s) => s.navigate);
  const clearCart = useELAYA((s) => s.clearCart);
  const setLastOrder = useELAYA((s) => s.setLastOrder);

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [payment, setPayment] = useState<PaymentMethod>("cod");
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  const subtotal = cartSubtotal(cart);
  const delivery = deliveryFeeFor(subtotal);
  const total = subtotal + delivery;

  const set = (key: keyof FormState) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    if (errors[key]) setErrors((er) => ({ ...er, [key]: undefined }));
  };

  /* ── Empty state ── */
  if (cart.length === 0) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center bg-cream px-4 py-28 text-center">
        <p className="font-serif text-3xl text-charcoal">Your bag is empty</p>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Add a bag (or design your own) before checking out.
        </p>
        <button
          type="button"
          onClick={() => navigate({ view: "shop" })}
          className="mt-7 rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
        >
          Shop Collection
        </button>
      </div>
    );
  }

  const orderSummaryText = () => {
    const lines: string[] = [
      "Assalam-o-Alaikum ELAYA! I would like to place an order:",
      "",
      ...cart.map(
        (item, i) =>
          `${i + 1}. ${item.name} × ${item.qty} — ${formatPKR(item.unitPrice * item.qty)}`
      ),
      "",
      `Subtotal: ${formatPKR(subtotal)}`,
      `Delivery: ${delivery === 0 ? "Free" : formatPKR(delivery)}`,
      `Total: ${formatPKR(total)}`,
      "",
    ];
    return lines.join("\n");
  };

  const submitOrder = async (viaWhatsApp = false) => {
    const errs = validate(form);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      toast({
        title: "Please check the form",
        description: "Some details are missing or need fixing.",
        variant: "destructive",
      });
      return;
    }

    if (viaWhatsApp) {
      const link = whatsappLink(
        `${orderSummaryText()}Name: ${form.name}\nPhone: ${form.phone}\nCity: ${form.city}\nAddress: ${form.address}${form.notes ? `\nNotes: ${form.notes}` : ""}`
      );
      if (!link) {
        toast({
          title: "WhatsApp ordering not configured",
          description:
            "The store owner hasn't added a WhatsApp number yet — please place your order with the form instead.",
        });
        return;
      }
      window.open(link, "_blank", "noopener");
      return;
    }

    setSubmitting(true);
    setServerError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: {
            name: form.name.trim(),
            phone: form.phone.trim(),
            email: form.email.trim() || undefined,
            city: form.city.trim(),
            address: form.address.trim(),
            notes: form.notes.trim() || undefined,
          },
          paymentMethod: payment,
          items: cart.map((item: CartItem) => ({
            productId: item.productId,
            name: item.name,
            color: item.color,
            qty: item.qty,
            unitPrice: item.unitPrice,
            customization: item.customization ?? null,
          })),
          subtotal,
          deliveryFee: delivery,
          total,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setServerError(data?.error ?? "We couldn't save your order. Please try again.");
        return;
      }
      // Order actually saved server-side — now show success
      setLastOrder({
        orderNumber: data.orderNumber,
        placedAt: data.placedAt,
        total,
        paymentMethod: payment === "cod" ? "Cash on Delivery" : "Bank Transfer",
        itemCount: cart.reduce((n, i) => n + i.qty, 0),
      });
      clearCart();
      navigate({ view: "order-success" });
    } catch {
      setServerError(
        "Network problem — your order was not placed. Please check your connection and try again."
      );
    } finally {
      setSubmitting(false);
    }
  };

  const inputCls = (key: keyof FormState) =>
    cn(
      "w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground/50 focus:shadow-[0_0_0_4px_rgba(217,166,160,0.18)]",
      errors[key] ? "border-destructive" : "border-input focus:border-rose-dust"
    );

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <button onClick={() => navigate({ view: "cart" })} className="hover:text-burgundy">
              Shopping Bag
            </button>
            <ChevronRight className="h-3 w-3" aria-hidden />
            <span className="text-charcoal/80">Checkout</span>
          </nav>
          <h1 className="display-3 mt-2 font-serif text-charcoal">Checkout</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            A few details and your bag will be on its way.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
          {/* ── Form ── */}
          <div className="space-y-8">
            <section aria-labelledby="delivery-heading" className="rounded-3xl border border-border bg-white p-6 shadow-[0_4px_24px_rgba(104,45,59,0.05)] md:p-8">
              <h2 id="delivery-heading" className="font-serif text-xl text-charcoal">
                Delivery details
              </h2>
              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                <Field label="Full name *" error={errors.name} htmlFor="co-name">
                  <input
                    id="co-name"
                    type="text"
                    value={form.name}
                    onChange={set("name")}
                    placeholder="Ayesha Khan"
                    autoComplete="name"
                    className={inputCls("name")}
                    aria-invalid={!!errors.name}
                  />
                </Field>
                <Field label="Phone number *" error={errors.phone} htmlFor="co-phone">
                  <input
                    id="co-phone"
                    type="tel"
                    value={form.phone}
                    onChange={set("phone")}
                    placeholder="0300 1234567"
                    autoComplete="tel"
                    className={inputCls("phone")}
                    aria-invalid={!!errors.phone}
                  />
                </Field>
                <Field
                  label="Email (optional)"
                  error={errors.email}
                  htmlFor="co-email"
                  className="sm:col-span-2"
                >
                  <input
                    id="co-email"
                    type="email"
                    value={form.email}
                    onChange={set("email")}
                    placeholder="you@example.com"
                    autoComplete="email"
                    className={inputCls("email")}
                    aria-invalid={!!errors.email}
                  />
                </Field>
                <Field label="City *" error={errors.city} htmlFor="co-city">
                  <input
                    id="co-city"
                    type="text"
                    value={form.city}
                    onChange={set("city")}
                    placeholder="Lahore"
                    autoComplete="address-level2"
                    className={inputCls("city")}
                    aria-invalid={!!errors.city}
                  />
                </Field>
                <Field
                  label="Complete delivery address *"
                  error={errors.address}
                  htmlFor="co-address"
                  className="sm:col-span-2"
                >
                  <textarea
                    id="co-address"
                    value={form.address}
                    onChange={set("address")}
                    rows={3}
                    placeholder="House / hostel no., street, area, nearest landmark"
                    autoComplete="street-address"
                    className={cn(inputCls("address"), "resize-none")}
                    aria-invalid={!!errors.address}
                  />
                </Field>
                <Field label="Order notes (optional)" htmlFor="co-notes" className="sm:col-span-2">
                  <textarea
                    id="co-notes"
                    value={form.notes}
                    onChange={set("notes")}
                    rows={2}
                    placeholder="Anything we should know? e.g. gift, please call before delivery…"
                    className={cn(inputCls("notes"), "resize-none")}
                  />
                </Field>
              </div>
            </section>

            {/* Payment */}
            <section aria-labelledby="payment-heading" className="rounded-3xl border border-border bg-white p-6 shadow-[0_4px_24px_rgba(104,45,59,0.05)] md:p-8">
              <h2 id="payment-heading" className="font-serif text-xl text-charcoal">
                Payment method
              </h2>
              <div className="mt-5 space-y-3">
                <label
                  className={cn(
                    "flex cursor-pointer items-start gap-4 rounded-2xl border p-4 transition-all",
                    payment === "cod"
                      ? "border-burgundy bg-blush/40"
                      : "border-border hover:border-rose-dust"
                  )}
                >
                  <input
                    type="radio"
                    name="payment"
                    value="cod"
                    checked={payment === "cod"}
                    onChange={() => setPayment("cod")}
                    className="sr-only"
                  />
                  <Banknote className="mt-0.5 h-5 w-5 text-burgundy" aria-hidden />
                  <span>
                    <span className="block text-sm font-medium text-charcoal">
                      Cash on Delivery
                    </span>
                    <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                      Pay in cash when your bag arrives. Available across Pakistan.
                    </span>
                  </span>
                </label>

                {SITE_CONFIG.bankTransfer.enabled && (
                  <label
                    className={cn(
                      "flex cursor-pointer items-start gap-4 rounded-2xl border p-4 transition-all",
                      payment === "bank_transfer"
                        ? "border-burgundy bg-blush/40"
                        : "border-border hover:border-rose-dust"
                    )}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value="bank_transfer"
                      checked={payment === "bank_transfer"}
                      onChange={() => setPayment("bank_transfer")}
                      className="sr-only"
                    />
                    <Building2 className="mt-0.5 h-5 w-5 text-burgundy" aria-hidden />
                    <span className="flex-1">
                      <span className="block text-sm font-medium text-charcoal">
                        Bank Transfer
                      </span>
                      <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                        Transfer the total to the account below, then place the
                        order — we confirm once the transfer is received.
                      </span>
                      {payment === "bank_transfer" && (
                        <span className="mt-3 block rounded-xl bg-secondary/70 p-4 text-[13px] leading-relaxed text-charcoal/85">
                          <strong>{SITE_CONFIG.bankTransfer.bankName}</strong>
                          <br />
                          Account title: {SITE_CONFIG.bankTransfer.accountTitle}
                          <br />
                          Account no.: {SITE_CONFIG.bankTransfer.accountNumber}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              navigator.clipboard
                                ?.writeText(SITE_CONFIG.bankTransfer.accountNumber)
                                .then(() =>
                                  toast({ title: "Account number copied" })
                                )
                                .catch(() => {});
                            }}
                            className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-burgundy/30 px-3 py-1 text-[11px] font-medium text-burgundy hover:bg-white"
                          >
                            <Copy className="h-3 w-3" aria-hidden />
                            Copy number
                          </button>
                          <span className="mt-2 block text-[11px] text-muted-foreground">
                            (Sample account details — the store owner will replace
                            these before going live.)
                          </span>
                        </span>
                      )}
                    </span>
                  </label>
                )}
              </div>
              <p className="mt-4 flex items-start gap-2 text-[12px] leading-relaxed text-muted-foreground">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-sage" aria-hidden />
                This is a prototype checkout — no online card payments are
                processed. Orders are saved so the ELAYA team can confirm them
                with you.
              </p>
            </section>

            {serverError && (
              <p role="alert" className="rounded-2xl border border-destructive/30 bg-destructive/5 px-5 py-4 text-sm text-destructive">
                {serverError}
              </p>
            )}
          </div>

          {/* ── Summary ── */}
          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="rounded-3xl border border-border bg-white p-6 shadow-[0_10px_36px_rgba(104,45,59,0.08)]">
              <h2 className="font-serif text-xl text-charcoal">Your order</h2>
              <ul className="mt-4 space-y-3">
                {cart.map((item) => (
                  <li key={item.key} className="flex items-start justify-between gap-3 text-[13px]">
                    <span className="text-charcoal/80">
                      {item.name}
                      <span className="text-muted-foreground"> × {item.qty}</span>
                      {item.customization?.initials && (
                        <span className="block text-[11px] text-burgundy">
                          “{item.customization.initials}”
                        </span>
                      )}
                    </span>
                    <span className="shrink-0 font-medium">
                      {formatPKR(item.unitPrice * item.qty)}
                    </span>
                  </li>
                ))}
              </ul>
              <dl className="mt-5 space-y-2.5 border-t border-dashed border-border pt-4 text-sm">
                <div className="flex justify-between">
                  <dt className="text-charcoal/70">Subtotal</dt>
                  <dd>{formatPKR(subtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-charcoal/70">Delivery</dt>
                  <dd>{delivery === 0 ? "Free" : formatPKR(delivery)}</dd>
                </div>
                <div className="flex justify-between border-t border-dashed border-border pt-3">
                  <dt className="text-[13px] font-semibold uppercase tracking-[0.14em]">Total</dt>
                  <dd className="font-serif text-2xl text-burgundy">{formatPKR(total)}</dd>
                </div>
              </dl>

              <button
                type="button"
                onClick={() => submitOrder(false)}
                disabled={submitting}
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-burgundy py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:bg-burgundy-deep hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    Placing your order…
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4" aria-hidden />
                    Place Order — {formatPKR(total)}
                  </>
                )}
              </button>

              {SITE_CONFIG.whatsappNumber ? (
                <button
                  type="button"
                  onClick={() => submitOrder(true)}
                  className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-full border py-3.5 text-xs font-medium uppercase tracking-[0.16em] text-charcoal transition-colors hover:bg-secondary"
                  style={{ borderColor: "#25D36655" }}
                >
                  <MessageCircle className="h-4 w-4" aria-hidden />
                  Order via WhatsApp
                </button>
              ) : (
                <p className="mt-3 rounded-xl bg-secondary/60 px-4 py-3 text-[11px] leading-relaxed text-muted-foreground">
                  WhatsApp ordering will be enabled once the store adds its
                  WhatsApp number in the site configuration.
                </p>
              )}

              <p className="mt-4 text-center text-[11px] leading-relaxed text-muted-foreground">
                Estimated delivery: {SITE_CONFIG.deliveryTime} · Free returns
                within 7 days
              </p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  error,
  htmlFor,
  children,
  className,
}: {
  label: string;
  error?: string;
  htmlFor: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className="mb-2 block text-[13px] font-medium text-charcoal">
        {label}
      </label>
      {children}
      {error && (
        <p role="alert" className="mt-1.5 text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}
