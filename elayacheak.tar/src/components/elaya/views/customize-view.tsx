"use client";

import { useMemo, useState, useSyncExternalStore } from "react";
import Image from "next/image";
import {
  BadgeCheck,
  Bookmark,
  Check,
  PenLine,
  RotateCcw,
  ShoppingBag,
  Sparkles,
  Trash2,
} from "lucide-react";
import {
  ACCESSORIES,
  BAG_STYLES,
  CUSTOMIZE_COLORS,
  CUSTOMIZE_LIMITS,
  DECOR_ELEMENTS,
  DEFAULT_CUSTOMIZATION,
  GIFT_PACKAGING,
  calculateCustomization,
  CustomizationState,
} from "@/lib/customize-options";
import { formatPKR } from "@/lib/config";
import { useELAYA } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Reveal } from "@/components/elaya/reveal";

const SAVED_DESIGNS_KEY = "elaya-saved-designs-v1";
const SAVED_DESIGNS_EVENT = "elaya-saved-designs-changed";

interface SavedDesign {
  id: string;
  name: string;
  state: CustomizationState;
  total: number;
  savedAt: string;
}

/** localStorage-backed store for saved designs (SSR-safe, lint-clean) */
function subscribeSaved(cb: () => void) {
  window.addEventListener(SAVED_DESIGNS_EVENT, cb);
  window.addEventListener("storage", cb);
  return () => {
    window.removeEventListener(SAVED_DESIGNS_EVENT, cb);
    window.removeEventListener("storage", cb);
  };
}
function getSavedSnapshot(): string {
  return localStorage.getItem(SAVED_DESIGNS_KEY) ?? "[]";
}
function getSavedServerSnapshot(): string {
  return "[]";
}
function writeSaved(designs: SavedDesign[]) {
  localStorage.setItem(SAVED_DESIGNS_KEY, JSON.stringify(designs));
  window.dispatchEvent(new Event(SAVED_DESIGNS_EVENT));
}

function parseSaved(json: string): SavedDesign[] {
  try {
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function CustomizeView() {
  const [state, setState] = useState<CustomizationState>(DEFAULT_CUSTOMIZATION);
  const [initialsError, setInitialsError] = useState("");
  const [messageError, setMessageError] = useState("");

  const savedJson = useSyncExternalStore(
    subscribeSaved,
    getSavedSnapshot,
    getSavedServerSnapshot
  );
  const saved = useMemo(() => parseSaved(savedJson), [savedJson]);

  const navigate = useELAYA((s) => s.navigate);
  const addToCart = useELAYA((s) => s.addToCart);
  const setCartOpen = useELAYA((s) => s.setCartOpen);

  const style = BAG_STYLES.find((s) => s.id === state.styleId) ?? BAG_STYLES[0];
  const color = CUSTOMIZE_COLORS.find((c) => c.id === state.colorId) ?? CUSTOMIZE_COLORS[0];
  const pricing = useMemo(() => calculateCustomization(state), [state]);

  const initialsValid = useMemo(() => {
    if (state.initials.length > CUSTOMIZE_LIMITS.initials.max) return false;
    if (state.initials.length > 0 && !/^[a-zA-Z\s.'-]+$/.test(state.initials)) return false;
    return true;
  }, [state.initials]);

  const messageValid = useMemo(() => {
    if (state.message.length > CUSTOMIZE_LIMITS.message.max) return false;
    return true;
  }, [state.message]);

  const canAdd = initialsValid && messageValid;

  const update = (patch: Partial<CustomizationState>) =>
    setState((s) => ({ ...s, ...patch }));

  const toggleIn = (list: string[], id: string) =>
    list.includes(id) ? list.filter((v) => v !== id) : [...list, id];

  const reset = () => {
    setState(DEFAULT_CUSTOMIZATION);
    setInitialsError("");
    setMessageError("");
    toast({ title: "Design reset", description: "Back to a blank canvas." });
  };

  const handleInitials = (value: string) => {
    if (value.length > CUSTOMIZE_LIMITS.initials.max) {
      setInitialsError(`Up to ${CUSTOMIZE_LIMITS.initials.max} characters only.`);
    } else if (value.length > 0 && !/^[a-zA-Z\s.'-]+$/.test(value)) {
      setInitialsError("Letters, spaces, dots and hyphens only.");
    } else {
      setInitialsError("");
    }
    update({ initials: value });
  };

  const handleMessage = (value: string) => {
    if (value.length > CUSTOMIZE_LIMITS.message.max) {
      setMessageError(`Up to ${CUSTOMIZE_LIMITS.message.max} characters only.`);
    } else {
      setMessageError("");
    }
    update({ message: value });
  };

  const cartCustomization = () => ({
    styleName: style.name,
    colorName: color.name,
    initials: state.initials.trim() || undefined,
    message: state.message.trim() || undefined,
    decor: state.decorIds.map(
      (id) => DECOR_ELEMENTS.find((d) => d.id === id)?.name ?? id
    ),
    accessories: state.accessoryIds.map(
      (id) => ACCESSORIES.find((a) => a.id === id)?.name ?? id
    ),
    packaging: GIFT_PACKAGING.find((g) => g.id === state.giftPackagingId)?.name,
  });

  const handleAddToCart = () => {
    if (!canAdd) return;
    addToCart({
      productId: `custom-${Date.now()}`,
      name: `Custom ${style.name} — ${state.initials.trim() || "ELAYA Design"}`,
      image: style.image,
      unitPrice: pricing.total,
      color: color.name,
      qty: 1,
      isCustom: true,
      customization: cartCustomization(),
    });
    setCartOpen(true);
    toast({
      title: "Added to cart",
      description: `Your custom ${style.name} (${formatPKR(pricing.total)}) is in your bag.`,
    });
  };

  const handleSave = () => {
    if (!canAdd) return;
    const design: SavedDesign = {
      id: `d-${Date.now()}`,
      name: `${style.name} — ${state.initials.trim() || color.name}`,
      state,
      total: pricing.total,
      savedAt: new Date().toISOString(),
    };
    const next = [design, ...saved].slice(0, 6);
    writeSaved(next);
    toast({ title: "Design saved", description: "Find it below to load later." });
  };

  const loadDesign = (d: SavedDesign) => {
    setState(d.state);
    toast({ title: "Design loaded", description: d.name });
  };

  const deleteDesign = (id: string) => {
    const next = saved.filter((d) => d.id !== id);
    writeSaved(next);
  };

  return (
    <div className="bg-cream pb-20">
      {/* Header */}
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6 md:py-14 lg:px-8">
          <p className="eyebrow text-burgundy/70">The ELAYA Atelier</p>
          <h1 className="display-2 mt-3 text-charcoal">
            Your Bag. <span className="italic text-burgundy">Your Personality.</span>
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
            Make it yours. Choose the details that turn your handbag into
            something personal — your price updates live as you design.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-12">
          {/* ── Steps ── */}
          <div className="space-y-10">
            {/* Step 1 — style */}
            <Reveal>
              <section aria-labelledby="step-style">
                <h2 id="step-style" className="display-3 font-serif text-charcoal">
                  1 · Choose your style
                </h2>
                <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                  {BAG_STYLES.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      aria-pressed={state.styleId === s.id}
                      onClick={() => update({ styleId: s.id })}
                      className={cn(
                        "group overflow-hidden rounded-2xl border-2 bg-white text-left transition-all duration-300",
                        state.styleId === s.id
                          ? "border-burgundy shadow-[0_10px_30px_rgba(104,45,59,0.15)]"
                          : "border-transparent shadow-sm hover:border-rose-dust"
                      )}
                    >
                      <div className="relative aspect-square">
                        <Image
                          src={s.image}
                          alt={s.name}
                          fill
                          sizes="160px"
                          className="zoom-img object-cover"
                        />
                        {state.styleId === s.id && (
                          <span className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-burgundy text-white">
                            <Check className="h-3.5 w-3.5" aria-hidden />
                          </span>
                        )}
                      </div>
                      <div className="p-3">
                        <p className="text-[13px] font-medium leading-tight text-charcoal">
                          {s.name}
                        </p>
                        <p className="mt-1 text-xs text-burgundy">
                          {formatPKR(s.basePrice)}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
                <p className="mt-3 text-[13px] italic text-muted-foreground">
                  {style.blurb}
                </p>
              </section>
            </Reveal>

            {/* Step 2 — colour */}
            <Reveal>
              <section aria-labelledby="step-color">
                <h2 id="step-color" className="display-3 font-serif text-charcoal">
                  2 · Pick your colour
                </h2>
                <div className="mt-5 flex flex-wrap gap-3">
                  {CUSTOMIZE_COLORS.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      role="radio"
                      aria-checked={state.colorId === c.id}
                      aria-label={`${c.name}${c.priceDelta ? ` (+${formatPKR(c.priceDelta)})` : ""}`}
                      onClick={() => update({ colorId: c.id })}
                      className={cn(
                        "flex flex-col items-center gap-1.5 rounded-2xl border p-3 transition-all duration-300",
                        state.colorId === c.id
                          ? "border-burgundy bg-blush/50"
                          : "border-border bg-white hover:border-rose-dust"
                      )}
                    >
                      <span
                        className="h-9 w-9 rounded-full border border-black/10 shadow-inner"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="text-[11px] text-charcoal/80">{c.name}</span>
                      {c.priceDelta > 0 && (
                        <span className="text-[10px] text-burgundy">
                          +{formatPKR(c.priceDelta)}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </section>
            </Reveal>

            {/* Step 3 — decorative details */}
            <Reveal>
              <section aria-labelledby="step-decor">
                <h2 id="step-decor" className="display-3 font-serif text-charcoal">
                  3 · Decorative details
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Choose as many as you like.
                </p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  {DECOR_ELEMENTS.map((d) => {
                    const active = state.decorIds.includes(d.id);
                    return (
                      <button
                        key={d.id}
                        type="button"
                        role="checkbox"
                        aria-checked={active}
                        onClick={() => update({ decorIds: toggleIn(state.decorIds, d.id) })}
                        className={cn(
                          "flex items-start gap-3 rounded-2xl border p-4 text-left transition-all duration-300",
                          active
                            ? "border-burgundy bg-blush/40"
                            : "border-border bg-white hover:border-rose-dust"
                        )}
                      >
                        <span
                          className={cn(
                            "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-colors",
                            active ? "border-burgundy bg-burgundy text-white" : "border-input bg-white"
                          )}
                        >
                          {active && <Check className="h-3 w-3" aria-hidden />}
                        </span>
                        <span>
                          <span className="flex items-center justify-between gap-2">
                            <span className="text-sm font-medium text-charcoal">{d.name}</span>
                            <span className="text-xs text-burgundy">+{formatPKR(d.price)}</span>
                          </span>
                          <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                            {d.description}
                          </span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            </Reveal>

            {/* Step 4 — initials + message */}
            <Reveal>
              <section aria-labelledby="step-text">
                <h2 id="step-text" className="display-3 font-serif text-charcoal">
                  4 · Make it personal
                </h2>
                <div className="mt-5 grid gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="custom-initials"
                      className="text-[13px] font-medium uppercase tracking-[0.12em] text-charcoal"
                    >
                      Name or initials{" "}
                      <span className="normal-case text-muted-foreground">(free)</span>
                    </label>
                    <input
                      id="custom-initials"
                      type="text"
                      value={state.initials}
                      onChange={(e) => handleInitials(e.target.value)}
                      placeholder="e.g. AYESHA or A.K."
                      maxLength={CUSTOMIZE_LIMITS.initials.max + 4}
                      aria-invalid={!!initialsError}
                      className={cn(
                        "mt-2 w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground/50 focus:shadow-[0_0_0_4px_rgba(217,166,160,0.2)]",
                        initialsError ? "border-destructive" : "border-input focus:border-rose-dust"
                      )}
                    />
                    <div className="mt-1.5 flex justify-between text-[11px]">
                      {initialsError ? (
                        <p role="alert" className="text-destructive">{initialsError}</p>
                      ) : (
                        <span className="text-muted-foreground">Up to 12 characters</span>
                      )}
                      <span className={state.initials.length > 12 ? "text-destructive" : "text-muted-foreground"}>
                        {state.initials.length}/12
                      </span>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="custom-message"
                      className="text-[13px] font-medium uppercase tracking-[0.12em] text-charcoal"
                    >
                      Personalized message{" "}
                      <span className="normal-case text-burgundy">(+{formatPKR(CUSTOMIZE_LIMITS.messagePrice)})</span>
                    </label>
                    <textarea
                      id="custom-message"
                      value={state.message}
                      onChange={(e) => handleMessage(e.target.value)}
                      placeholder="e.g. To my favourite person — enjoy every moment."
                      rows={3}
                      maxLength={CUSTOMIZE_LIMITS.message.max + 10}
                      aria-invalid={!!messageError}
                      className={cn(
                        "mt-2 w-full resize-none rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground/50 focus:shadow-[0_0_0_4px_rgba(217,166,160,0.2)]",
                        messageError ? "border-destructive" : "border-input focus:border-rose-dust"
                      )}
                    />
                    <div className="mt-1.5 flex justify-between text-[11px]">
                      {messageError ? (
                        <p role="alert" className="text-destructive">{messageError}</p>
                      ) : (
                        <span className="text-muted-foreground">Optional, up to 60 characters</span>
                      )}
                      <span className={state.message.length > 60 ? "text-destructive" : "text-muted-foreground"}>
                        {state.message.length}/60
                      </span>
                    </div>
                  </div>
                </div>
              </section>
            </Reveal>

            {/* Step 5 — accessories */}
            <Reveal>
              <section aria-labelledby="step-accessories">
                <h2 id="step-accessories" className="display-3 font-serif text-charcoal">
                  5 · Accessories
                </h2>
                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  {ACCESSORIES.map((a) => {
                    const active = state.accessoryIds.includes(a.id);
                    return (
                      <button
                        key={a.id}
                        type="button"
                        role="checkbox"
                        aria-checked={active}
                        onClick={() =>
                          update({ accessoryIds: toggleIn(state.accessoryIds, a.id) })
                        }
                        className={cn(
                          "rounded-2xl border p-4 text-left transition-all duration-300",
                          active
                            ? "border-burgundy bg-blush/40"
                            : "border-border bg-white hover:border-rose-dust"
                        )}
                      >
                        <span className="flex items-center justify-between">
                          <span className="text-sm font-medium text-charcoal">{a.name}</span>
                          {active && <BadgeCheck className="h-4 w-4 text-burgundy" aria-hidden />}
                        </span>
                        <span className="mt-1 block text-xs text-burgundy">
                          +{formatPKR(a.price)}
                        </span>
                        <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                          {a.description}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            </Reveal>

            {/* Step 6 — gift packaging */}
            <Reveal>
              <section aria-labelledby="step-gift">
                <h2 id="step-gift" className="display-3 font-serif text-charcoal">
                  6 · Gift packaging
                </h2>
                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  {GIFT_PACKAGING.map((g) => {
                    const active = state.giftPackagingId === g.id;
                    return (
                      <button
                        key={g.id}
                        type="button"
                        role="radio"
                        aria-checked={active}
                        onClick={() => update({ giftPackagingId: g.id })}
                        className={cn(
                          "rounded-2xl border p-4 text-left transition-all duration-300",
                          active
                            ? "border-burgundy bg-blush/40"
                            : "border-border bg-white hover:border-rose-dust"
                        )}
                      >
                        <span className="flex items-center justify-between">
                          <span className="text-sm font-medium text-charcoal">{g.name}</span>
                          {active && <Check className="h-4 w-4 text-burgundy" aria-hidden />}
                        </span>
                        <span className="mt-1 block text-xs text-burgundy">
                          {g.price === 0 ? "Included" : `+${formatPKR(g.price)}`}
                        </span>
                        <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                          {g.description}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>
            </Reveal>

            {/* Saved designs */}
            {saved.length > 0 && (
              <Reveal>
                <section aria-labelledby="saved-designs" className="rounded-3xl border border-border bg-white/70 p-6">
                  <h2 id="saved-designs" className="font-serif text-xl text-charcoal">
                    Saved designs
                  </h2>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Stored on this device only — load one to continue where you left off.
                  </p>
                  <ul className="mt-4 space-y-2.5">
                    {saved.map((d) => (
                      <li
                        key={d.id}
                        className="flex items-center justify-between gap-3 rounded-xl bg-secondary/50 px-4 py-3"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-charcoal">{d.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatPKR(d.total)} · saved {new Date(d.savedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex shrink-0 items-center gap-2">
                          <button
                            type="button"
                            onClick={() => loadDesign(d)}
                            className="rounded-full bg-burgundy px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.12em] text-primary-foreground hover:bg-burgundy-deep"
                          >
                            Load
                          </button>
                          <button
                            type="button"
                            aria-label={`Delete saved design ${d.name}`}
                            onClick={() => deleteDesign(d.id)}
                            className="text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" aria-hidden />
                          </button>
                        </div>
                      </li>
                    ))}
                  </ul>
                </section>
              </Reveal>
            )}
          </div>

          {/* ── Live preview ── */}
          <div className="lg:sticky lg:top-28 lg:self-start">
            <div className="overflow-hidden rounded-[1.75rem] border border-border bg-white shadow-[0_16px_50px_rgba(104,45,59,0.10)]">
              {/* Preview visual */}
              <div className="relative aspect-[4/3] overflow-hidden bg-beige-soft">
                <Image
                  src={style.image}
                  alt={`${style.name} preview`}
                  fill
                  sizes="400px"
                  className="object-cover transition-all duration-700"
                  style={{ filter: "saturate(0.92)" }}
                />
                <div
                  aria-hidden
                  className="absolute inset-0 transition-colors duration-700"
                  style={{ backgroundColor: `${color.hex}26` }}
                />
                <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-white/90 px-3.5 py-1.5 shadow-sm backdrop-blur">
                  <span
                    className="h-3.5 w-3.5 rounded-full border border-black/10"
                    style={{ backgroundColor: color.hex }}
                  />
                  <span className="text-[11px] font-medium text-charcoal">{color.name}</span>
                </div>
                <div className="absolute bottom-4 left-4 right-4 rounded-xl bg-charcoal/70 px-4 py-2.5 backdrop-blur">
                  <p className="text-[11px] uppercase tracking-[0.18em] text-cream/70">
                    Live preview · summary
                  </p>
                  <p className="truncate font-serif text-[15px] text-cream">
                    {style.name}
                    {state.initials.trim() ? ` — “${state.initials.trim()}”` : ""}
                  </p>
                </div>
              </div>

              {/* Summary */}
              <div className="p-6">
                <ul className="space-y-2 text-[13px]">
                  <SummaryRow label={`${style.name} (base + colour)`} value={formatPKR(pricing.basePrice)} strong />
                  {state.decorIds.length > 0 && (
                    <SummaryRow
                      label={state.decorIds
                        .map((id) => DECOR_ELEMENTS.find((d) => d.id === id)?.name)
                        .join(" + ")}
                      value={`+ ${formatPKR(pricing.decorTotal)}`}
                    />
                  )}
                  {state.message.trim() && (
                    <SummaryRow label="Personalized message" value={`+ ${formatPKR(pricing.messageTotal)}`} />
                  )}
                  {state.accessoryIds.length > 0 && (
                    <SummaryRow
                      label={state.accessoryIds
                        .map((id) => ACCESSORIES.find((a) => a.id === id)?.name)
                        .join(" + ")}
                      value={`+ ${formatPKR(pricing.accessoryTotal)}`}
                    />
                  )}
                  {pricing.packagingTotal > 0 && (
                    <SummaryRow
                      label={GIFT_PACKAGING.find((g) => g.id === state.giftPackagingId)?.name ?? ""}
                      value={`+ ${formatPKR(pricing.packagingTotal)}`}
                    />
                  )}
                  {state.initials.trim() && (
                    <li className="flex items-start gap-2 pt-1 text-[12px] text-muted-foreground">
                      <PenLine className="mt-0.5 h-3.5 w-3.5 shrink-0 text-burgundy" aria-hidden />
                      “{state.initials.trim()}” will be added in gold-tone lettering
                    </li>
                  )}
                  {state.message.trim() && (
                    <li className="flex items-start gap-2 text-[12px] text-muted-foreground">
                      <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-burgundy" aria-hidden />
                      “{state.message.trim()}”
                    </li>
                  )}
                </ul>

                <div className="mt-5 flex items-center justify-between border-t border-dashed border-border pt-4">
                  <span className="text-[13px] font-medium uppercase tracking-[0.16em] text-charcoal">
                    Your price
                  </span>
                  <span className="font-serif text-2xl text-burgundy">
                    {formatPKR(pricing.total)}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleAddToCart}
                  disabled={!canAdd}
                  className="mt-5 flex w-full items-center justify-center gap-2.5 rounded-full bg-burgundy py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:bg-burgundy-deep hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <ShoppingBag className="h-4 w-4" aria-hidden />
                  Add Customized Bag to Cart
                </button>

                <div className="mt-2.5 grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={!canAdd}
                    className="flex items-center justify-center gap-2 rounded-full border border-burgundy/30 py-3 text-[11px] font-medium uppercase tracking-[0.14em] text-burgundy transition-colors hover:bg-secondary disabled:opacity-50"
                  >
                    <Bookmark className="h-3.5 w-3.5" aria-hidden />
                    Save Design
                  </button>
                  <button
                    type="button"
                    onClick={reset}
                    className="flex items-center justify-center gap-2 rounded-full border border-border py-3 text-[11px] font-medium uppercase tracking-[0.14em] text-charcoal/70 transition-colors hover:bg-secondary"
                  >
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                    Reset
                  </button>
                </div>

                <p className="mt-4 text-center text-[11px] leading-relaxed text-muted-foreground">
                  Custom bags are handmade to order and dispatch within 7–9
                  working days. All options shown are currently available.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  strong = false,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <li className="flex items-start justify-between gap-3">
      <span className={cn("text-charcoal/80", strong && "font-medium text-charcoal")}>
        {label}
      </span>
      <span className={cn("shrink-0 text-charcoal/80", strong && "font-semibold text-burgundy")}>
        {value}
      </span>
    </li>
  );
}
