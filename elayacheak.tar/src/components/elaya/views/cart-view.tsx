"use client";

import Image from "next/image";
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useELAYA, cartSubtotal, deliveryFeeFor } from "@/lib/store";
import { PRODUCTS } from "@/lib/products";
import { SITE_CONFIG, formatPKR } from "@/lib/config";

export function CartView() {
  const cart = useELAYA((s) => s.cart);
  const setQty = useELAYA((s) => s.setQty);
  const removeFromCart = useELAYA((s) => s.removeFromCart);
  const navigate = useELAYA((s) => s.navigate);

  const subtotal = cartSubtotal(cart);
  const delivery = deliveryFeeFor(subtotal);

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6 md:py-12 lg:px-8">
          <p className="eyebrow text-burgundy/70">Almost Yours</p>
          <h1 className="display-2 mt-3 text-charcoal">Shopping Bag</h1>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center rounded-3xl border border-dashed border-border bg-white/60 px-6 py-24 text-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-beige-soft">
              <ShoppingBag className="h-8 w-8 text-rose-dust" aria-hidden />
            </span>
            <p className="mt-6 font-serif text-2xl text-charcoal">Your bag is empty</p>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
              Fill it with something beautiful — everyday totes, evening
              classics, or a design that is entirely your own.
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={() => navigate({ view: "shop" })}
                className="rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
              >
                Shop Collection
              </button>
              <button
                type="button"
                onClick={() => navigate({ view: "customize" })}
                className="rounded-full border border-burgundy/35 px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-burgundy hover:bg-secondary"
              >
                Create Your Own
              </button>
            </div>
          </div>
        ) : (
          <div className="grid gap-10 lg:grid-cols-[1fr_360px]">
            {/* Items */}
            <ul className="space-y-5">
              {cart.map((item) => (
                <li
                  key={item.key}
                  className="flex flex-col gap-4 rounded-3xl border border-border/70 bg-white p-5 shadow-[0_4px_20px_rgba(104,45,59,0.05)] sm:flex-row"
                >
                  <button
                    type="button"
                    aria-label={`View ${item.name}`}
                    onClick={() => {
                      if (item.isCustom) return;
                      const product = PRODUCTS.find((p) => p.id === item.productId);
                      if (product) navigate({ view: "product", slug: product.slug });
                    }}
                    className="group relative h-36 w-32 shrink-0 overflow-hidden rounded-2xl bg-beige-soft self-center sm:self-start"
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="128px"
                      className="zoom-img object-cover"
                    />
                  </button>

                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="font-serif text-[17px] text-charcoal">{item.name}</h2>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Colour: {item.color} · {formatPKR(item.unitPrice)} each
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-label={`Remove ${item.name}`}
                        onClick={() => removeFromCart(item.key)}
                        className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-blush hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" aria-hidden />
                      </button>
                    </div>

                    {item.customization && (
                      <div className="mt-3 rounded-xl bg-secondary/60 px-4 py-3">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-burgundy">
                          Your customization
                        </p>
                        <ul className="mt-1.5 space-y-1 text-xs leading-relaxed text-charcoal/75">
                          {item.customization.styleName && (
                            <li>Style: {item.customization.styleName}</li>
                          )}
                          {item.customization.initials && (
                            <li>Name/initials: “{item.customization.initials}”</li>
                          )}
                          {item.customization.decor.length > 0 && (
                            <li>Details: {item.customization.decor.join(", ")}</li>
                          )}
                          {item.customization.message && (
                            <li>Message: “{item.customization.message}”</li>
                          )}
                          {item.customization.accessories.length > 0 && (
                            <li>Accessories: {item.customization.accessories.join(", ")}</li>
                          )}
                          {item.customization.packaging &&
                            item.customization.packaging !== "No gift packaging" && (
                              <li>Packaging: {item.customization.packaging}</li>
                            )}
                        </ul>
                      </div>
                    )}

                    <div className="mt-auto flex items-center justify-between pt-4">
                      <div className="flex items-center rounded-full border border-input bg-cream">
                        <button
                          type="button"
                          aria-label="Decrease quantity"
                          onClick={() => setQty(item.key, item.qty - 1)}
                          className="flex h-10 w-10 items-center justify-center rounded-full hover:text-burgundy"
                        >
                          <Minus className="h-4 w-4" aria-hidden />
                        </button>
                        <span className="w-7 text-center text-sm font-medium" aria-live="polite">
                          {item.qty}
                        </span>
                        <button
                          type="button"
                          aria-label="Increase quantity"
                          onClick={() => setQty(item.key, item.qty + 1)}
                          className="flex h-10 w-10 items-center justify-center rounded-full hover:text-burgundy"
                        >
                          <Plus className="h-4 w-4" aria-hidden />
                        </button>
                      </div>
                      <p className="font-serif text-lg text-burgundy">
                        {formatPKR(item.unitPrice * item.qty)}
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            {/* Summary */}
            <aside className="lg:sticky lg:top-28 lg:self-start">
              <div className="rounded-3xl border border-border bg-white p-6 shadow-[0_10px_36px_rgba(104,45,59,0.08)]">
                <h2 className="font-serif text-xl text-charcoal">Order Summary</h2>
                <dl className="mt-5 space-y-3 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-charcoal/70">Subtotal ({cart.length} items)</dt>
                    <dd className="font-medium">{formatPKR(subtotal)}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-charcoal/70">Delivery</dt>
                    <dd className="font-medium">
                      {delivery === 0 ? (
                        <span className="text-sage">Free</span>
                      ) : (
                        formatPKR(delivery)
                      )}
                    </dd>
                  </div>
                  <div className="flex justify-between border-t border-dashed border-border pt-3">
                    <dt className="text-[13px] font-semibold uppercase tracking-[0.14em]">
                      Total
                    </dt>
                    <dd className="font-serif text-2xl text-burgundy">
                      {formatPKR(subtotal + delivery)}
                    </dd>
                  </div>
                </dl>
                <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                  {SITE_CONFIG.freeDeliveryThreshold > 0 &&
                    `Free delivery on orders above ${formatPKR(SITE_CONFIG.freeDeliveryThreshold)}. `}
                  Pay with Cash on Delivery or Bank Transfer.
                </p>
                <button
                  type="button"
                  onClick={() => navigate({ view: "checkout" })}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-burgundy py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:bg-burgundy-deep hover:shadow-lg"
                >
                  Proceed to Checkout
                  <ArrowRight className="h-4 w-4" aria-hidden />
                </button>
                <button
                  type="button"
                  onClick={() => navigate({ view: "shop" })}
                  className="mt-2 w-full rounded-full py-3 text-xs font-medium uppercase tracking-[0.16em] text-burgundy hover:bg-secondary"
                >
                  Continue Shopping
                </button>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
