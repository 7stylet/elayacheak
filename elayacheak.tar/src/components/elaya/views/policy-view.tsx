"use client";

import { Reveal } from "@/components/elaya/reveal";
import { SITE_CONFIG, formatPKR } from "@/lib/config";
import { useELAYA } from "@/lib/store";

type PolicyKey = "shipping" | "returns" | "privacy" | "terms";

const POLICIES: Record<
  PolicyKey,
  { title: string; intro: string; sections: { heading: string; body: string[] }[] }
> = {
  shipping: {
    title: "Shipping Policy",
    intro:
      "We keep shipping simple, honest and affordable — because the excitement of ordering should last right up to the moment your bag arrives.",
    sections: [
      {
        heading: "Delivery charges",
        body: [
          `We charge a flat delivery fee of ${formatPKR(SITE_CONFIG.deliveryFee)} per order anywhere in Pakistan. Orders with a subtotal of ${formatPKR(SITE_CONFIG.freeDeliveryThreshold)} or more are delivered free of charge.`,
          "For customized bags, delivery is charged the same way — the personalization price you see in the atelier always includes the finished product; only standard delivery applies at checkout.",
        ],
      },
      {
        heading: "Delivery timelines",
        body: [
          `Ready-made bags are dispatched within ${SITE_CONFIG.deliveryTime} of order confirmation. You will receive a confirmation call or message before dispatch, and courier tracking details where available.`,
          "Customized and personalized bags are handmade to order, so please allow 7–9 working days for production before dispatch. We promise the wait is worth it.",
          "Delivery timelines may extend slightly around public holidays, adverse weather or for remote areas — if that happens, we'll keep you informed.",
        ],
      },
      {
        heading: "Cash on Delivery & payment",
        body: [
          "Cash on Delivery (COD) is available across Pakistan. Please keep the exact amount ready for the rider — our courier partners may not always carry change.",
          `Bank transfer is also accepted; your order is confirmed once the transfer is received in the account shown at checkout. Online card payments are not processed on this website${SITE_CONFIG.whatsappNumber ? ", and WhatsApp ordering is available" : ""}.`,
        ],
      },
      {
        heading: "Order confirmation",
        body: [
          "Every order receives a quick confirmation call or message to verify the address and details. If we cannot reach you within 3 working days of the order, the order may be placed on hold until we reconnect.",
        ],
      },
    ],
  },
  returns: {
    title: "Returns & Exchanges",
    intro:
      "We want you to love your ELAYA bag. If something isn't right, here is exactly how we make it right — no fine-print games.",
    sections: [
      {
        heading: "7-day exchange window",
        body: [
          "If your bag is unused, in its original packaging with tags intact, you may request an exchange or return within 7 days of delivery. Simply contact us with your order number and a photo of the item.",
          "Returns are accepted for manufacturing faults, damage in transit, or if you received the wrong item. For change-of-mind exchanges, the bag must be in brand-new, resalable condition.",
        ],
      },
      {
        heading: "Personalized & customized items",
        body: [
          "Customized and personalized bags are made specifically for you and cannot be returned or exchanged for change of mind — but if there is a fault in the bag or in the personalization itself, we will absolutely make it right with a repair, replacement or refund.",
          "Please double-check spellings and colour choices in the atelier before adding a custom design to your cart. We confirm all details on the order call as an extra safety net.",
        ],
      },
      {
        heading: "How refunds work",
        body: [
          "Once a returned bag reaches us and passes a quick quality check, refunds are issued within 7 working days. For COD orders, refunds are sent via bank transfer or easy mobile-wallet transfer. For bank-transfer payments, refunds return to the same account.",
          "Original delivery charges are refunded only when the return is due to our error (faulty, damaged or wrong item).",
        ],
      },
      {
        heading: "Non-returnable conditions",
        body: [
          "Bags showing signs of use, wear, stains or missing tags; items returned after the 7-day window; and items damaged through misuse (as described in each product's care instructions) cannot be accepted for return.",
        ],
      },
    ],
  },
  privacy: {
    title: "Privacy Policy",
    intro:
      "Your trust matters as much as your style. This policy explains, in plain language, what we collect and how we protect it.",
    sections: [
      {
        heading: "What we collect",
        body: [
          "When you place an order, we collect your name, phone number, city and delivery address so the bag actually reaches you. Email is optional and only used for order updates and (with your consent) our newsletter.",
          "If you contact us or design a custom bag, we collect the details you choose to share — messages, personalization text and design preferences.",
          "Your cart, wishlist and saved designs are stored locally on your own device (browser storage), not on our servers.",
        ],
      },
      {
        heading: "How we use it",
        body: [
          "Your information is used only to process and deliver orders, confirm details with you, respond to your questions and — only if you subscribed — send occasional newsletter updates.",
          "We do not sell, rent or trade your personal information to third parties. Delivery details are shared with our courier partners strictly for the purpose of delivering your order.",
        ],
      },
      {
        heading: "Data retention & your choices",
        body: [
          "Order records are kept for as long as needed for delivery, exchanges and honest accounting, then deleted. You can ask us at any time to correct or delete your information by emailing us — we'll action it within a reasonable period.",
          "You can unsubscribe from the newsletter at any time by contacting us. Choosing not to provide an email never blocks you from ordering.",
        ],
      },
      {
        heading: "A note on payment safety",
        body: [
          "We never see or store card details — this website processes no card payments at all. Payments happen via Cash on Delivery or direct bank transfer between you and our account.",
        ],
      },
    ],
  },
  terms: {
    title: "Terms & Conditions",
    intro:
      "The ground rules of shopping with ELAYA — written to be read, not to be skipped.",
    sections: [
      {
        heading: "The basics",
        body: [
          "By using this website and placing an order, you agree to these terms. ELAYA is a women's handbag brand operating in Pakistan; all prices are listed in Pakistani Rupees (PKR).",
          "Product photography is styled in soft natural light; slight colour variation between screens and the finished bag can occur and does not constitute a defect.",
        ],
      },
      {
        heading: "Orders & pricing",
        body: [
          "All product information, prices and availability shown on the site are sample placeholder data during development and may be updated by the store at any time. If a price or availability error is discovered after you order, we will contact you before processing.",
          "An order is confirmed only after our team verifies the details with you. We reserve the right to decline orders in cases of unverifiable addresses, repeated failed deliveries, or suspected fraud.",
        ],
      },
      {
        heading: "Customized designs",
        body: [
          "You confirm you hold the rights to any name, initials or text you ask us to personalize. We may politely decline personalization text that is offensive, infringes others' rights or violates any law.",
          "Customized bags are made to the specifications shown in your cart summary and re-confirmed on the order call; they cannot be exchanged for change of mind after production begins.",
        ],
      },
      {
        heading: "Website content & liability",
        body: [
          "All text, imagery and design on this website belong to ELAYA and may not be copied for commercial use without permission. Sample reviews, testimonial data and social links shown during development are placeholders and will be replaced with verified content.",
          "To the fullest extent permitted by law, ELAYA's liability for any claim related to a purchase is limited to the amount you paid for the product.",
        ],
      },
      {
        heading: "Changes to these terms",
        body: [
          "We may update these terms as the store grows. The version published on this page at the time of your order applies to that order.",
        ],
      },
    ],
  },
};

export function PolicyView({ policy }: { policy: PolicyKey }) {
  const navigate = useELAYA((s) => s.navigate);
  const data = POLICIES[policy];

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center sm:px-6 lg:px-8">
          <p className="eyebrow text-burgundy/70">ELAYA Policies</p>
          <h1 className="display-2 mt-3 text-charcoal">{data.title}</h1>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 pt-12 sm:px-6">
        <Reveal>
          <p className="font-serif text-lg leading-relaxed italic text-charcoal/85">
            {data.intro}
          </p>
        </Reveal>

        <div className="mt-10 space-y-8">
          {data.sections.map((section, i) => (
            <Reveal key={section.heading} delay={i * 0.05}>
              <section className="rounded-3xl border border-border/80 bg-white p-7 shadow-[0_2px_14px_rgba(104,45,59,0.04)] md:p-8">
                <h2 className="font-serif text-xl text-charcoal">
                  <span className="mr-2 text-burgundy">{String(i + 1).padStart(2, "0")}</span>
                  {section.heading}
                </h2>
                <div className="mt-4 space-y-4">
                  {section.body.map((para, j) => (
                    <p key={j} className="text-[15px] leading-relaxed text-muted-foreground">
                      {para}
                    </p>
                  ))}
                </div>
              </section>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1} className="mt-10 text-center">
          <p className="text-sm text-muted-foreground">
            Questions about this policy? We&apos;re happy to explain.
          </p>
          <button
            type="button"
            onClick={() => navigate({ view: "contact" })}
            className="mt-4 rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
          >
            Contact Us
          </button>
        </Reveal>
      </div>
    </div>
  );
}
