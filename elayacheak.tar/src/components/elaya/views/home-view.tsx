"use client";

import { Hero } from "@/components/elaya/sections/hero";
import { CollectionsSection } from "@/components/elaya/sections/collections";
import { FeaturedProducts } from "@/components/elaya/sections/featured-products";
import { CustomizeTeaser } from "@/components/elaya/sections/customize-teaser";
import { BrandStory } from "@/components/elaya/sections/brand-story";
import { WhyChoose } from "@/components/elaya/sections/why-choose";
import { Testimonials } from "@/components/elaya/sections/testimonials";
import { InstagramSection } from "@/components/elaya/sections/instagram-section";

export function HomeView() {
  return (
    <>
      <Hero />
      <CollectionsSection />
      <FeaturedProducts />
      <CustomizeTeaser />
      <BrandStory />
      <WhyChoose />
      <Testimonials />
      <InstagramSection />
    </>
  );
}
