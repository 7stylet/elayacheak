"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import {
  Check,
  ChevronRight,
  Heart,
  Minus,
  Package,
  Plus,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Truck,
} from "lucide-react";
import { useELAYA } from "@/lib/store";
import {
  getProductBySlug,
  getRelatedProducts,
  COLLECTIONS,
} from "@/lib/products";
import { formatPKRDisplay } from "@/lib/product-utils";
import { SITE_CONFIG, formatPKR } from "@/lib/config";
import { ProductCard } from "@/components/elaya/product-card";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

const MAX_QTY = 9;

export function ProductView({ slug }: { slug?: string }) {
  const product = useMemo(() => (slug ? getProductBySlug(slug) : undefined), [slug]);
  const navigate = useELAYA((s) => s.navigate);
  const addToCart = useELAYA((s) => s.addToCart);
  const setCartOpen = useELAYA((s) => s.setCartOpen);
  const wishlist = useELAYA((s) => s.wishlist);
  const toggleWishlist = useELAYA((s) => s.toggleWishlist);

  const [activeImage, setActiveImage] = useState(0);
  const [colorIdx, setColorIdx] = useState(0);
  const [qty, setQty] = useState(1);

  // Reset selections when navigating between products
  const productKey = product?.id ?? "none";
  const [lastKey, setLastKey] = useState(productKey);
  if (lastKey !== productKey) {
    setLastKey(productKey);
    setActiveImage(0);
    setColorIdx(0);
    setQty(1);
  }

  if (!product) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center px-4 py-28 text-center">
        <p className="font-serif text-3xl text-charcoal">This bag wandered off</p>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          We couldn&apos;t find the product you were looking for. It may have
          been renamed — browse the collection to find something beautiful.
        </p>
        <Button
          onClick={() => navigate({ view: "shop" })}
          className="mt-7 rounded-full bg-burgundy px-8 py-3 text-xs uppercase tracking-[0.18em] hover:bg-burgundy-deep"
        >
          Browse Collection
        </Button>
      </div>
    );
  }

  const collection = COLLECTIONS.find((c) => c.id === product.collection);
  const color = product.colors[colorIdx] ?? product.colors[0];
  const unitPrice = product.price + (color?.priceDelta ?? 0);
  const wishlisted = wishlist.includes(product.id);
  const related = getRelatedProducts(product);

  const buildItem = () => ({
    productId: product.id,
    name: product.name,
    image: product.images[0],
    unitPrice,
    color: color.name,
    qty,
  });

  const handleAddToCart = () => {
    addToCart(buildItem());
    setCartOpen(true);
    toast({ title: "Added to cart", description: `${product.name} · ${color.name}` });
  };

  const handleBuyNow = () => {
    addToCart(buildItem());
    navigate({ view: "checkout" });
  };

  const handleWishlist = () => {
    toggleWishlist(product.id);
    toast({
      title: wishlisted ? "Removed from wishlist" : "Saved to wishlist",
      description: product.name,
    });
  };

  return (
    <div className="bg-cream pb-20">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="border-b border-border/70 bg-secondary/30">
        <ol className="mx-auto flex max-w-7xl flex-wrap items-center gap-1.5 px-4 py-3.5 text-xs text-muted-foreground sm:px-6 lg:px-8">
          <li>
            <button onClick={() => navigate({ view: "home" })} className="hover:text-burgundy">
              Home
            </button>
          </li>
          <ChevronRight className="h-3 w-3" aria-hidden />
          <li>
            <button onClick={() => navigate({ view: "shop" })} className="hover:text-burgundy">
              Shop All
            </button>
          </li>
          {collection && (
            <>
              <ChevronRight className="h-3 w-3" aria-hidden />
              <li>
                <button
                  onClick={() => navigate({ view: "shop", collection: collection.id })}
                  className="hover:text-burgundy"
                >
                  {collection.name}
                </button>
              </li>
            </>
          )}
          <ChevronRight className="h-3 w-3" aria-hidden />
          <li aria-current="page" className="truncate text-charcoal/80">
            {product.name}
          </li>
        </ol>
      </nav>

      <div className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          {/* ── Gallery ── */}
          <div>
            <div className="relative aspect-square overflow-hidden rounded-[1.75rem] bg-beige-soft shadow-[0_10px_40px_rgba(104,45,59,0.10)]">
              <Image
                key={product.images[activeImage]}
                src={product.images[activeImage]}
                alt={`${product.name} — view ${activeImage + 1}`}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 45vw"
                className="animate-fade-up object-cover"
              />
              {product.badge && (
                <span className="absolute left-4 top-4 rounded-full bg-burgundy px-4 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-primary-foreground">
                  {product.badge}
                </span>
              )}
            </div>
            {/* Thumbnails */}
            <div className="mt-4 flex gap-3">
              {product.images.map((img, i) => (
                <button
                  key={img}
                  type="button"
                  aria-label={`View image ${i + 1}`}
                  aria-pressed={activeImage === i}
                  onClick={() => setActiveImage(i)}
                  className={cn(
                    "relative h-20 w-20 overflow-hidden rounded-xl bg-beige-soft transition-all duration-300",
                    activeImage === i
                      ? "ring-2 ring-burgundy ring-offset-2 ring-offset-cream"
                      : "opacity-70 hover:opacity-100"
                  )}
                >
                  <Image src={img} alt="" fill sizes="80px" className="object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* ── Info ── */}
          <div>
            {collection && (
              <button
                onClick={() => navigate({ view: "shop", collection: collection.id })}
                className="eyebrow text-burgundy/70 hover:text-burgundy"
              >
                {collection.name}
              </button>
            )}
            <h1 className="display-3 mt-2 font-serif text-charcoal">{product.name}</h1>

            <div className="mt-3 flex items-center gap-3">
              <p className="font-serif text-2xl text-burgundy">
                {formatPKRDisplay(unitPrice)}
              </p>
              {product.compareAtPrice && (
                <p className="text-base text-muted-foreground line-through">
                  {formatPKRDisplay(product.compareAtPrice)}
                </p>
              )}
              {color.priceDelta ? (
                <span className="rounded-full bg-blush px-2.5 py-1 text-[11px] text-burgundy">
                  +{formatPKR(color.priceDelta)} for {color.name}
                </span>
              ) : null}
            </div>

            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-0.5" aria-hidden>
                {Array.from({ length: 5 }).map((_, i) => (
                  <span
                    key={i}
                    className={cn(
                      "inline-block h-2 w-2 rounded-full",
                      i < Math.round(product.rating) ? "bg-gold" : "bg-border"
                    )}
                  />
                ))}
              </span>
              <span>
                {product.rating.toFixed(1)} ({product.reviewCount} reviews)
              </span>
              <span aria-hidden>·</span>
              <span className={product.inStock ? "text-sage" : "text-destructive"}>
                {product.inStock ? "In stock" : "Out of stock"}
              </span>
            </div>

            <p className="mt-5 text-[15px] leading-relaxed text-charcoal/80">
              {product.description}
            </p>

            {/* Colours */}
            <div className="mt-7">
              <p className="text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal">
                Colour — <span className="text-muted-foreground">{color.name}</span>
              </p>
              <div className="mt-3 flex flex-wrap gap-3" role="radiogroup" aria-label="Choose colour">
                {product.colors.map((c, i) => (
                  <button
                    key={c.name}
                    type="button"
                    role="radio"
                    aria-checked={i === colorIdx}
                    aria-label={c.name}
                    onClick={() => setColorIdx(i)}
                    className={cn(
                      "relative h-10 w-10 rounded-full border shadow-sm transition-all duration-300",
                      i === colorIdx
                        ? "border-burgundy ring-2 ring-burgundy ring-offset-2 ring-offset-cream"
                        : "border-black/10 hover:scale-110"
                    )}
                    style={{ backgroundColor: c.hex }}
                  >
                    {i === colorIdx && (
                      <Check
                        className="absolute inset-0 m-auto h-4 w-4 text-white drop-shadow"
                        aria-hidden
                      />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity + actions */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <div className="flex items-center rounded-full border border-input bg-white">
                <button
                  type="button"
                  aria-label="Decrease quantity"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  disabled={qty <= 1}
                  className="flex h-11 w-11 items-center justify-center rounded-full text-charcoal disabled:opacity-40 hover:text-burgundy"
                >
                  <Minus className="h-4 w-4" aria-hidden />
                </button>
                <span className="w-8 text-center font-medium" aria-live="polite">
                  {qty}
                </span>
                <button
                  type="button"
                  aria-label="Increase quantity"
                  onClick={() => setQty((q) => Math.min(MAX_QTY, q + 1))}
                  disabled={qty >= MAX_QTY}
                  className="flex h-11 w-11 items-center justify-center rounded-full text-charcoal disabled:opacity-40 hover:text-burgundy"
                >
                  <Plus className="h-4 w-4" aria-hidden />
                </button>
              </div>

              <button
                type="button"
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="min-w-[180px] flex-1 rounded-full bg-burgundy px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:bg-burgundy-deep hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-50 sm:flex-none"
              >
                Add to Cart
              </button>

              <button
                type="button"
                onClick={handleBuyNow}
                disabled={!product.inStock}
                className="min-w-[180px] flex-1 rounded-full border border-burgundy bg-white px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy transition-all duration-300 hover:bg-burgundy hover:text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50 sm:flex-none"
              >
                Buy Now
              </button>

              <button
                type="button"
                onClick={handleWishlist}
                aria-pressed={wishlisted}
                aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-full border transition-all duration-300",
                  wishlisted
                    ? "border-burgundy bg-burgundy text-primary-foreground"
                    : "border-border bg-white text-charcoal hover:border-burgundy hover:text-burgundy"
                )}
              >
                <Heart className={cn("h-4.5 w-4.5", wishlisted && "fill-current")} aria-hidden />
              </button>
            </div>

            {/* Customizable hint */}
            {product.customizable && (
              <div className="mt-6 flex items-start gap-3 rounded-2xl border border-rose-dust/40 bg-blush/40 p-4">
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-burgundy" aria-hidden />
                <p className="text-[13px] leading-relaxed text-charcoal/80">
                  This bag can be personalized.{" "}
                  <button
                    type="button"
                    onClick={() => navigate({ view: "customize" })}
                    className="font-medium text-burgundy underline underline-offset-2 hover:text-burgundy-deep"
                  >
                    Design your own version
                  </button>{" "}
                  in the ELAYA atelier — add initials, decorative details and gift
                  packaging.
                </p>
              </div>
            )}

            {/* Perks */}
            <ul className="mt-8 grid gap-3 border-t border-border pt-7 text-[13px] text-charcoal/75 sm:grid-cols-2">
              <li className="flex items-center gap-2.5">
                <Truck className="h-4 w-4 text-burgundy" aria-hidden />
                Delivery in {SITE_CONFIG.deliveryTime}
              </li>
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="h-4 w-4 text-burgundy" aria-hidden />
                Cash on Delivery available
              </li>
              <li className="flex items-center gap-2.5">
                <RotateCcw className="h-4 w-4 text-burgundy" aria-hidden />
                7-day exchange policy
              </li>
              <li className="flex items-center gap-2.5">
                <Package className="h-4 w-4 text-burgundy" aria-hidden />
                Elegant, protected packaging
              </li>
            </ul>

            {/* Details accordion-ish sections */}
            <div className="mt-8 space-y-6 border-t border-border pt-7">
              <div>
                <p className="eyebrow mb-2 text-burgundy/70">Materials & Details</p>
                <p className="text-sm leading-relaxed text-charcoal/80">{product.material}</p>
                <p className="mt-1 text-sm leading-relaxed text-charcoal/80">
                  Dimensions: {product.dimensions}
                </p>
              </div>
              <div>
                <p className="eyebrow mb-2 text-burgundy/70">Highlights</p>
                <ul className="space-y-1.5">
                  {product.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-charcoal/80">
                      <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-burgundy" aria-hidden />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="eyebrow mb-2 text-burgundy/70">Care Instructions</p>
                <p className="text-sm leading-relaxed text-charcoal/80">{product.care}</p>
              </div>
              <div>
                <p className="eyebrow mb-2 text-burgundy/70">Delivery Information</p>
                <p className="text-sm leading-relaxed text-charcoal/80">
                  Orders are dispatched within {SITE_CONFIG.deliveryTime} across
                  Pakistan. Delivery is {formatPKR(SITE_CONFIG.deliveryFee)} — free
                  on orders above {formatPKR(SITE_CONFIG.freeDeliveryThreshold)}.
                  Pay with Cash on Delivery or Bank Transfer.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related */}
      <div className="mx-auto mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Complete the Look"
          title="You May Also Love"
          align="center"
        />
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">
          {related.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.06}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
