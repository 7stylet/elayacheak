"use client";

import { Heart, ShoppingBag } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { PRODUCTS } from "@/lib/products";
import { ProductCard } from "@/components/elaya/product-card";

export function WishlistView() {
  const wishlist = useELAYA((s) => s.wishlist);
  const navigate = useELAYA((s) => s.navigate);

  const saved = PRODUCTS.filter((p) => wishlist.includes(p.id));

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-10 text-center sm:px-6 md:py-12 lg:px-8">
          <p className="eyebrow text-burgundy/70">Saved With Love</p>
          <h1 className="display-2 mt-3 text-charcoal">Your Wishlist</h1>
          <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
            Bags you&apos;re dreaming about — saved on this device so they&apos;re
            here when you return.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
        {saved.length === 0 ? (
          <div className="flex flex-col items-center rounded-3xl border border-dashed border-border bg-white/60 px-6 py-24 text-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-blush">
              <Heart className="h-8 w-8 text-burgundy" aria-hidden />
            </span>
            <p className="mt-6 font-serif text-2xl text-charcoal">
              Nothing saved yet
            </p>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
              Tap the heart on any bag you love and it will wait for you here.
            </p>
            <button
              type="button"
              onClick={() => navigate({ view: "shop" })}
              className="mt-7 flex items-center gap-2 rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
            >
              <ShoppingBag className="h-4 w-4" aria-hidden />
              Discover the Collection
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4">
            {saved.map((p, i) => (
              <ProductCard key={p.id} product={p} priority={i < 2} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
