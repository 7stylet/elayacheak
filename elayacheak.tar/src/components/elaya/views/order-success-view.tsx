"use client";

import { CheckCircle2, Package, MessageCircle } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { SITE_CONFIG, formatPKR, whatsappLink } from "@/lib/config";

export function OrderSuccessView() {
  const lastOrder = useELAYA((s) => s.lastOrder);
  const navigate = useELAYA((s) => s.navigate);

  if (!lastOrder) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center bg-cream px-4 py-28 text-center">
        <p className="font-serif text-3xl text-charcoal">No recent order</p>
        <p className="mt-3 text-sm text-muted-foreground">
          Once you place an order, its confirmation will appear here.
        </p>
        <button
          type="button"
          onClick={() => navigate({ view: "shop" })}
          className="mt-7 rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
        >
          Shop Collection
        </button>
      </div>
    );
  }

  return (
    <div className="bg-cream pb-20">
      <div className="mx-auto max-w-2xl px-4 pt-16 text-center sm:px-6">
        <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-sage/20">
          <CheckCircle2 className="h-10 w-10 text-sage" aria-hidden />
        </span>
        <h1 className="display-2 mt-6 text-charcoal">
          Thank you, <span className="italic text-burgundy">your order is in!</span>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-[15px] leading-relaxed text-muted-foreground">
          Your order has been saved successfully. The ELAYA team will contact
          you shortly on your phone number to confirm the details before
          dispatch.
        </p>

        <div className="mt-10 rounded-3xl border border-border bg-white p-7 text-left shadow-[0_10px_36px_rgba(104,45,59,0.08)]">
          <div className="flex items-center justify-between gap-3 border-b border-dashed border-border pb-4">
            <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              Order number
            </span>
            <span className="font-serif text-lg text-burgundy">
              {lastOrder.orderNumber}
            </span>
          </div>
          <dl className="mt-4 space-y-2.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-charcoal/70">Items</dt>
              <dd>{lastOrder.itemCount}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-charcoal/70">Payment method</dt>
              <dd>{lastOrder.paymentMethod}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-charcoal/70">Total</dt>
              <dd className="font-semibold text-burgundy">{formatPKR(lastOrder.total)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-charcoal/70">Placed on</dt>
              <dd>{new Date(lastOrder.placedAt).toLocaleString()}</dd>
            </div>
          </dl>
          <p className="mt-5 flex items-start gap-2 rounded-xl bg-blush/40 px-4 py-3 text-[12px] leading-relaxed text-charcoal/75">
            <Package className="mt-0.5 h-4 w-4 shrink-0 text-burgundy" aria-hidden />
            {lastOrder.paymentMethod === "Bank Transfer"
              ? "Please complete your bank transfer using the account details shown at checkout — your order will be confirmed once the payment is received."
              : "Keep the exact amount ready for the rider. You'll receive a call before delivery."}
          </p>
        </div>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={() => navigate({ view: "shop" })}
            className="rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
          >
            Continue Shopping
          </button>
          {SITE_CONFIG.whatsappNumber && (
            <a
              href={whatsappLink(
                `Assalam-o-Alaikum! I just placed order ${lastOrder.orderNumber} on the ELAYA website.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-full border px-8 py-3.5 text-xs font-medium uppercase tracking-[0.16em] text-charcoal hover:bg-secondary"
            >
              <MessageCircle className="h-4 w-4" aria-hidden />
              Ask about my order
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
