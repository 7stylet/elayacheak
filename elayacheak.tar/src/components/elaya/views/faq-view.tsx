"use client";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Reveal } from "@/components/elaya/reveal";
import { SITE_CONFIG, formatPKR } from "@/lib/config";
import { useELAYA } from "@/lib/store";

const FAQS = [
  {
    q: "How do I place an order?",
    a: "Browse the shop or design your own custom bag, add your favourites to the cart, then check out with your name, phone number and address. You can pay with Cash on Delivery or Bank Transfer. Your order is saved and our team calls to confirm before dispatch.",
  },
  {
    q: "What are the delivery charges and timing?",
    a: `Delivery is ${formatPKR(SITE_CONFIG.deliveryFee)} flat, and free on orders above ${formatPKR(SITE_CONFIG.freeDeliveryThreshold)}. Orders arrive in ${SITE_CONFIG.deliveryTime}; customized bags take 7–9 working days because they're made especially for you.`,
  },
  {
    q: "Can I really personalize a bag with my name?",
    a: "Yes! In 'Customize Your Bag' you can choose the style, colour, decorative details and add a name, initials or a short message. The price updates live as you design. What you see listed is exactly what our atelier can currently produce.",
  },
  {
    q: "Which cities do you deliver to?",
    a: "We deliver across Pakistan — including Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan, Peshawar and most towns served by our courier partners.",
  },
  {
    q: "Can I return or exchange a bag?",
    a: "Yes — you can request an exchange or return within 7 days of delivery if the bag is unused and in its original packaging with tags intact. Personalized and customized bags are made just for you, so they can only be exchanged if there is a fault. See our Returns & Exchanges page for details.",
  },
  {
    q: "How do I take care of my bag?",
    a: "Wipe gently with a soft dry cloth, keep it away from prolonged sunlight and moisture, and store it in the dust bag provided. Each product page includes specific care instructions for its material.",
  },
  {
    q: "Is Cash on Delivery available?",
    a: `Yes, Cash on Delivery is available across Pakistan. Bank transfer is also accepted. You can order directly on the website${SITE_CONFIG.whatsappNumber ? " or through WhatsApp" : ""}.`,
  },
  {
    q: "Are the colours exactly as shown in photos?",
    a: "We photograph every bag in soft, natural light to show its true tone. Very slight variations can occur between screens and production batches — if a shade matters to your design, message us and we'll happily share extra photos.",
  },
];

export function FaqView() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <div className="bg-cream pb-20">
      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center sm:px-6 lg:px-8">
          <p className="eyebrow text-burgundy/70">Help Centre</p>
          <h1 className="display-2 mt-3 text-charcoal">Frequently Asked Questions</h1>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 pt-12 sm:px-6">
        <Reveal>
          <Accordion type="single" collapsible className="space-y-3">
            {FAQS.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="rounded-2xl border border-border/80 bg-white px-6 shadow-[0_2px_12px_rgba(104,45,59,0.04)] last:border-b"
              >
                <AccordionTrigger className="py-5 text-left font-serif text-[17px] text-charcoal hover:no-underline hover:text-burgundy">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="pb-6 text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>

        <Reveal delay={0.1} className="mt-10 text-center">
          <p className="text-sm text-muted-foreground">
            Still curious? We&apos;re one message away.
          </p>
          <button
            type="button"
            onClick={() => navigate({ view: "contact" })}
            className="mt-4 rounded-full bg-burgundy px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground hover:bg-burgundy-deep"
          >
            Contact Us
          </button>
        </Reveal>
      </div>
    </div>
  );
}
