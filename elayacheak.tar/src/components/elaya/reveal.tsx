"use client";

import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

interface RevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  y?: number;
  once?: boolean;
}

/** Fades content in as it scrolls into view. Respects reduced-motion. */
export function Reveal({ children, className, delay = 0, y = 26, once = true }: RevealProps) {
  const reduce = useReducedMotion();
  if (reduce) return <div className={className}>{children}</div>;
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: "-60px" }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

interface SectionHeadingProps {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: string;
  align?: "left" | "center";
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}: SectionHeadingProps) {
  return (
    <Reveal
      className={cn(
        "mb-10 md:mb-14",
        align === "center" ? "text-center mx-auto max-w-2xl" : "text-left",
        className
      )}
    >
      {eyebrow && <p className="eyebrow text-burgundy/70 mb-3">{eyebrow}</p>}
      <h2 className="display-2 text-charcoal text-balance">{title}</h2>
      {subtitle && (
        <p className="mt-4 text-muted-foreground text-[15px] md:text-base leading-relaxed max-w-xl mx-auto">
          {subtitle}
        </p>
      )}
      <span
        aria-hidden
        className={cn("mt-5 block h-px w-14 bg-rose-dust", align === "center" ? "mx-auto" : "")}
      />
    </Reveal>
  );
}
