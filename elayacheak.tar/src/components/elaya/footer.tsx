"use client";

import { useState } from "react";
import { Instagram, Loader2, Mail, MapPin, Send } from "lucide-react";
import { useELAYA, ViewName } from "@/lib/store";
import { SITE_CONFIG } from "@/lib/config";
import { cn } from "@/lib/utils";

export function Footer() {
  const navigate = useELAYA((s) => s.navigate);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">(
    "idle"
  );
  const [feedback, setFeedback] = useState("");

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(trimmed)) {
      setStatus("error");
      setFeedback("Please enter a valid email address.");
      return;
    }
    setStatus("loading");
    setFeedback("");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: trimmed }),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatus("error");
        setFeedback(data?.error ?? "Something went wrong. Please try again.");
        return;
      }
      setStatus("success");
      setFeedback(data.message ?? "You're on the list. Welcome to ELAYA.");
      setEmail("");
    } catch {
      setStatus("error");
      setFeedback("Network error — please check your connection and try again.");
    }
  };

  const linkCls =
    "text-left text-sm text-cream/70 transition-colors hover:text-rose-soft";

  return (
    <footer className="mt-auto bg-burgundy text-cream">
      <div className="mx-auto max-w-7xl px-4 pb-10 pt-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          {/* Brand */}
          <div>
            <p className="font-serif text-3xl font-semibold tracking-[0.18em] text-cream">
              ELAYA
            </p>
            <p className="mt-3 font-serif text-[15px] italic text-rose-soft">
              “{SITE_CONFIG.tagline}”
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream/70">
              Handbags designed for the everyday moments and the unforgettable
              ones — made for young women across Pakistan.
            </p>
            <div className="mt-5 space-y-2 text-sm text-cream/70">
              <p className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-rose-soft" aria-hidden />
                <a href={`mailto:${SITE_CONFIG.email}`} className="hover:text-rose-soft">
                  {SITE_CONFIG.email}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-rose-soft" aria-hidden />
                Delivery across Pakistan
              </p>
            </div>
            {/* Instagram */}
            {SITE_CONFIG.instagramUrl ? (
              <a
                href={SITE_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="ELAYA on Instagram"
                className="mt-5 inline-flex h-10 w-10 items-center justify-center rounded-full border border-cream/30 text-cream transition-colors hover:bg-cream hover:text-burgundy"
              >
                <Instagram className="h-4 w-4" aria-hidden />
              </a>
            ) : (
              <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-dashed border-cream/30 px-4 py-2 text-xs text-cream/60">
                <Instagram className="h-3.5 w-3.5" aria-hidden />
                Instagram — coming soon
              </p>
            )}
          </div>

          {/* Shop */}
          <nav aria-label="Shop links">
            <p className="eyebrow mb-4 text-rose-soft">Shop</p>
            <ul className="space-y-2.5">
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "shop" })}>
                  All Bags
                </button>
              </li>
              <li>
                <button
                  className={linkCls}
                  onClick={() => navigate({ view: "shop", collection: "new" })}
                >
                  New Arrivals
                </button>
              </li>
              <li>
                <button
                  className={linkCls}
                  onClick={() => navigate({ view: "shop", collection: "personalized" })}
                >
                  Personalized Bags
                </button>
              </li>
              <li>
                <button
                  className={linkCls}
                  onClick={() => navigate({ view: "shop", collection: "gift-collection" })}
                >
                  Gift Collection
                </button>
              </li>
            </ul>
          </nav>

          {/* Customer care */}
          <nav aria-label="Customer care links">
            <p className="eyebrow mb-4 text-rose-soft">Customer Care</p>
            <ul className="space-y-2.5">
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "contact" })}>
                  Contact Us
                </button>
              </li>
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "faq" })}>
                  FAQs
                </button>
              </li>
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "shipping" })}>
                  Shipping Information
                </button>
              </li>
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "returns" })}>
                  Returns &amp; Exchanges
                </button>
              </li>
            </ul>
          </nav>

          {/* Information */}
          <nav aria-label="Information links">
            <p className="eyebrow mb-4 text-rose-soft">Information</p>
            <ul className="space-y-2.5">
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "about" })}>
                  About ELAYA
                </button>
              </li>
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "privacy" })}>
                  Privacy Policy
                </button>
              </li>
              <li>
                <button className={linkCls} onClick={() => navigate({ view: "terms" })}>
                  Terms &amp; Conditions
                </button>
              </li>
            </ul>

            {/* Newsletter */}
            <div className="mt-7">
              <p className="eyebrow mb-2 text-rose-soft">Newsletter</p>
              <p className="mb-3 text-xs leading-relaxed text-cream/70">
                New arrivals, styling notes and early access — straight to your
                inbox.
              </p>
              <form onSubmit={handleSubscribe} noValidate>
                <div className="flex overflow-hidden rounded-full border border-cream/25 bg-cream/10 focus-within:border-rose-soft">
                  <label htmlFor="footer-newsletter" className="sr-only">
                    Email address
                  </label>
                  <input
                    id="footer-newsletter"
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (status !== "idle") setStatus("idle");
                    }}
                    placeholder="Your email address"
                    className="w-full bg-transparent px-4 py-2.5 text-sm text-cream outline-none placeholder:text-cream/40"
                    aria-invalid={status === "error"}
                  />
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    aria-label="Subscribe to newsletter"
                    className="flex w-12 shrink-0 items-center justify-center bg-rose-dust text-burgundy transition-colors hover:bg-rose-soft disabled:opacity-60"
                  >
                    {status === "loading" ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      <Send className="h-4 w-4" aria-hidden />
                    )}
                  </button>
                </div>
                {status === "error" && (
                  <p role="alert" className="mt-2 text-xs text-rose-soft">
                    {feedback}
                  </p>
                )}
                {status === "success" && (
                  <p role="status" className="mt-2 text-xs text-cream">
                    {feedback}
                  </p>
                )}
              </form>
            </div>
          </nav>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-cream/15 pt-6 text-xs text-cream/60 sm:flex-row">
          <p>{SITE_CONFIG.copyright}</p>
          <p className="flex items-center gap-4">
            <span>Cash on Delivery</span>
            <span aria-hidden>·</span>
            <span>Bank Transfer</span>
            <span aria-hidden>·</span>
            <span>{SITE_CONFIG.deliveryTime} delivery</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
