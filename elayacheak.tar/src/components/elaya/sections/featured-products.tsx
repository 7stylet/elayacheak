"use client";

import { ArrowRight } from "lucide-react";
import { PRODUCTS } from "@/lib/products";
import { useELAYA } from "@/lib/store";
import { ProductCard } from "@/components/elaya/product-card";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";

export function FeaturedProducts() {
  const navigate = useELAYA((s) => s.navigate);
  const featured = [...PRODUCTS].sort((a, b) => a.featuredRank - b.featuredRank).slice(0, 8);

  return (
    <section aria-labelledby="featured-heading" className="bg-secondary/45 py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Loved & Carried"
          title={<span id="featured-heading">Featured Pieces</span>}
          subtitle="The bags our customers reach for again and again — thoughtfully priced, boutique quality."
        />

        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4">
          {featured.map((p, i) => (
            <Reveal key={p.id} delay={(i % 4) * 0.07}>
              <ProductCard product={p} priority={i < 2} />
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center">
          <button
            type="button"
            onClick={() => navigate({ view: "shop" })}
            className="group inline-flex items-center gap-3 rounded-full border border-burgundy/35 bg-white px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy transition-all duration-300 hover:-translate-y-0.5 hover:bg-burgundy hover:text-primary-foreground hover:shadow-lg"
          >
            View All Bags
            <ArrowRight
              className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
              aria-hidden
            />
          </button>
        </Reveal>
      </div>
    </section>
  );
}
