"use client";

import { Quote, Star } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";

/**
 * ⚠️ SAMPLE TESTIMONIALS — clearly labelled during development.
 * Replace these with verified customer feedback before launch.
 */
const SAMPLE_REVIEWS = [
  {
    name: "Sample Review — Ayesha K.",
    initials: "AK",
    rating: 5,
    text: "The Rosé Mini Tote is exactly my style — light, pretty and it fits everything I need for uni. The quality genuinely surprised me at this price.",
    product: "ELAYA Rosé Mini Tote",
  },
  {
    name: "Sample Review — Mahnoor S.",
    initials: "MS",
    rating: 5,
    text: "I ordered the personalized initial bag as a birthday gift for my best friend. She almost cried! The packaging looked so elegant.",
    product: "ELAYA Personalized Initial Bag",
  },
  {
    name: "Sample Review — Fatima R.",
    initials: "FR",
    rating: 4,
    text: "Classic Charm in burgundy is my go-to for every dinner now. It holds its shape beautifully and the gold lock feels premium.",
    product: "ELAYA Classic Charm",
  },
  {
    name: "Sample Review — Zainab T.",
    initials: "ZT",
    rating: 5,
    text: "Everyday Muse carries my laptop, notebooks AND lunch without looking bulky. Perfect student bag honestly.",
    product: "ELAYA Everyday Muse",
  },
  {
    name: "Sample Review — Hira A.",
    initials: "HA",
    rating: 5,
    text: "The Signature Gift Bag made my sister's graduation so special. The box, ribbon, everything felt like a boutique experience.",
    product: "ELAYA Signature Gift Bag",
  },
  {
    name: "Sample Review — Laiba M.",
    initials: "LM",
    rating: 4,
    text: "Midnight Elegance is stunning in person. The chain strap is delicate but sturdy — got so many compliments at the mehndi.",
    product: "ELAYA Midnight Elegance",
  },
];

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`Rated ${rating} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          aria-hidden
          className={
            i < rating
              ? "h-3.5 w-3.5 fill-gold text-gold"
              : "h-3.5 w-3.5 text-border"
          }
        />
      ))}
    </div>
  );
}

export function Testimonials() {
  return (
    <section aria-labelledby="reviews-heading" className="bg-cream py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Kind Words"
          title={<span id="reviews-heading">From Our Customers</span>}
          subtitle="The reviews below are clearly-labelled samples for development — they will be replaced with verified customer feedback."
        />

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {SAMPLE_REVIEWS.map((review, i) => (
            <Reveal key={review.name} delay={(i % 3) * 0.08}>
              <figure className="relative h-full rounded-3xl border border-border/70 bg-white p-7 shadow-[0_4px_20px_rgba(104,45,59,0.05)] transition-shadow duration-500 hover:shadow-[0_16px_40px_rgba(104,45,59,0.12)]">
                <Quote
                  aria-hidden
                  className="absolute right-6 top-6 h-8 w-8 text-rose-soft/60"
                />
                <Stars rating={review.rating} />
                <blockquote className="mt-4 text-sm leading-relaxed text-charcoal/85">
                  “{review.text}”
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-dashed border-border pt-5">
                  <span
                    aria-hidden
                    className="flex h-10 w-10 items-center justify-center rounded-full bg-burgundy text-xs font-semibold text-primary-foreground"
                  >
                    {review.initials}
                  </span>
                  <div>
                    <p className="text-[13px] font-medium text-charcoal">
                      {review.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Purchased: {review.product}
                    </p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
