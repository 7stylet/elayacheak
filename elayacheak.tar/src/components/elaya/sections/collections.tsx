"use client";

import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { COLLECTIONS } from "@/lib/products";
import { useELAYA } from "@/lib/store";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";

export function CollectionsSection() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <section aria-labelledby="collections-heading" className="bg-cream py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Shop by Collection"
          title={<span id="collections-heading">Find the Bag for Your Moment</span>}
          subtitle="Four curated collections — from lecture-hall practical to celebration-ready, and everything personal in between."
        />

        <div className="grid gap-6 sm:grid-cols-2 lg:gap-8">
          {COLLECTIONS.map((c, i) => (
            <Reveal key={c.id} delay={i * 0.08}>
              <article
                role="link"
                tabIndex={0}
                aria-label={`Explore ${c.name}`}
                onClick={() => navigate({ view: "shop", collection: c.id })}
                onKeyDown={(e) => {
                  if (e.key === "Enter") navigate({ view: "shop", collection: c.id });
                }}
                className="group relative cursor-pointer overflow-hidden rounded-[1.75rem] shadow-[0_8px_30px_rgba(104,45,59,0.08)] transition-shadow duration-500 hover:shadow-[0_20px_50px_rgba(104,45,59,0.18)] focus-visible:outline-2 focus-visible:outline-burgundy"
              >
                <div className="relative aspect-[4/3.4] sm:aspect-[4/3]">
                  <Image
                    src={c.image}
                    alt={c.name}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 50vw"
                    className="zoom-img object-cover"
                  />
                  <div
                    aria-hidden
                    className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-charcoal/20 to-transparent"
                  />
                </div>

                <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
                  <h3 className="font-serif text-2xl text-white md:text-[28px]">
                    {c.name}
                  </h3>
                  <p className="mt-2 max-w-md text-[13px] leading-relaxed text-white/85 md:text-sm">
                    {c.shortDescription}
                  </p>
                  <span className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-white backdrop-blur transition-all duration-300 group-hover:bg-white group-hover:text-burgundy">
                    Explore Collection
                    <ArrowRight
                      className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1"
                      aria-hidden
                    />
                  </span>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
