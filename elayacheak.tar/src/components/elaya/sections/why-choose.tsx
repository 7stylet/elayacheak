"use client";

import { CalendarHeart, Gem, GraduationCap, HeartHandshake } from "lucide-react";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";

const REASONS = [
  {
    icon: Gem,
    title: "Personalized Style",
    text: "Choose designs and available details that reflect your personality.",
  },
  {
    icon: HeartHandshake,
    title: "Thoughtful Pricing",
    text: "Discover attractive styles at prices designed to suit different budgets.",
  },
  {
    icon: GraduationCap,
    title: "Made for Everyday Moments",
    text: "Explore bags for university, shopping, outings, and special occasions.",
  },
  {
    icon: CalendarHeart,
    title: "Gift-Worthy Designs",
    text: "Make birthdays, celebrations, and thoughtful surprises more memorable.",
  },
];

export function WhyChoose() {
  return (
    <section aria-labelledby="why-heading" className="bg-secondary/45 py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Why Choose ELAYA?"
          title={<span id="why-heading">Designed Around You</span>}
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {REASONS.map((reason, i) => (
            <Reveal key={reason.title} delay={i * 0.08}>
              <article className="group h-full rounded-3xl border border-border/70 bg-white p-7 shadow-[0_4px_20px_rgba(104,45,59,0.05)] transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_18px_44px_rgba(104,45,59,0.13)]">
                <span className="flex h-13 w-13 items-center justify-center rounded-2xl bg-blush text-burgundy transition-all duration-500 group-hover:bg-burgundy group-hover:text-primary-foreground">
                  <reason.icon className="h-6 w-6" aria-hidden />
                </span>
                <h3 className="mt-5 font-serif text-[19px] leading-snug text-charcoal">
                  {reason.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
                  {reason.text}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
