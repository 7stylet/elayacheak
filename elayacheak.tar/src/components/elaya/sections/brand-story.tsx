"use client";

import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { Reveal } from "@/components/elaya/reveal";

export function BrandStory() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <section aria-labelledby="story-heading" className="bg-cream py-16 md:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        {/* Image */}
        <Reveal className="relative">
          <div className="relative aspect-[4/3] overflow-hidden rounded-[2rem] shadow-[0_24px_60px_rgba(104,45,59,0.14)]">
            <Image
              src="/images/about.png"
              alt="The ELAYA studio with handbags, fabric swatches and dried flowers"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="zoom-img object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -right-2 hidden rounded-2xl bg-burgundy px-6 py-5 text-cream shadow-xl sm:block lg:-right-6">
            <p className="font-serif text-lg italic">Every detail, considered.</p>
            <p className="mt-1 text-xs text-cream/75">
              Designed with love, priced with care
            </p>
          </div>
        </Reveal>

        {/* Copy */}
        <div>
          <Reveal>
            <p className="eyebrow text-burgundy/70">Our Story</p>
            <h2 id="story-heading" className="display-2 mt-3 text-charcoal text-balance">
              Every Bag Has a Story.{" "}
              <span className="italic text-burgundy">Yours Starts Here.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="mt-6 space-y-5 text-[15px] leading-relaxed text-muted-foreground">
              <p>
                ELAYA was created with a simple idea: a handbag should be more
                than something you carry. It should reflect your personality,
                complement your style, and accompany you through life&apos;s
                everyday moments.
              </p>
              <p>
                From practical everyday bags to thoughtful personalized designs,
                we believe every woman deserves something that feels uniquely
                hers.
              </p>
              <p className="font-serif text-[17px] italic text-charcoal">
                At ELAYA, your style inspires our designs, and your story makes
                them special.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.2}>
            <button
              type="button"
              onClick={() => navigate({ view: "about" })}
              className="group mt-8 inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy"
            >
              <span className="link-underline">Read our full story</span>
              <ArrowRight
                className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                aria-hidden
              />
            </button>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
