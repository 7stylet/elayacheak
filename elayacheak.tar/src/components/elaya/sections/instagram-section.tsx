"use client";

import Image from "next/image";
import { Heart, Instagram } from "lucide-react";
import { SITE_CONFIG } from "@/lib/config";
import { Reveal, SectionHeading } from "@/components/elaya/reveal";

const GRID_IMAGES = [
  { src: "/images/insta-1.png", alt: "Street style with a dusty rose ELAYA bag" },
  { src: "/images/insta-2.png", alt: "Flat-lay of a burgundy bag with gold accessories" },
  { src: "/images/insta-3.png", alt: "Blush handbag by a vanity mirror" },
  { src: "/images/insta-4.png", alt: "ELAYA gift packaging with ribbon and card" },
  { src: "/images/insta-5.png", alt: "Taupe tote on a study desk with notebooks" },
  { src: "/images/insta-6.png", alt: "Leather swatches in ELAYA's signature palette" },
];

export function InstagramSection() {
  return (
    <section aria-labelledby="insta-heading" className="bg-secondary/45 py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="@ELAYA"
          title={<span id="insta-heading">Style Looks Better with ELAYA.</span>}
          subtitle="Styling ideas, colour pairings, gift moments and behind-the-scenes peeks from the ELAYA world."
        />

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-5">
          {GRID_IMAGES.map((img, i) => (
            <Reveal key={img.src} delay={(i % 3) * 0.07}>
              <div className="group relative aspect-square overflow-hidden rounded-2xl bg-beige-soft">
                <Image
                  src={img.src}
                  alt={img.alt}
                  fill
                  sizes="(max-width: 640px) 50vw, 33vw"
                  className="zoom-img object-cover"
                />
                <div
                  aria-hidden
                  className="absolute inset-0 flex items-center justify-center bg-burgundy/0 opacity-0 transition-all duration-500 group-hover:bg-burgundy/35 group-hover:opacity-100"
                >
                  <Heart className="h-7 w-7 text-white" aria-hidden />
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 text-center">
          {SITE_CONFIG.instagramUrl ? (
            <a
              href={SITE_CONFIG.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-3 rounded-full bg-burgundy px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-all duration-300 hover:-translate-y-0.5 hover:bg-burgundy-deep hover:shadow-lg"
            >
              <Instagram className="h-4 w-4" aria-hidden />
              Follow ELAYA on Instagram
            </a>
          ) : (
            <div className="inline-flex flex-col items-center gap-2">
              <span className="inline-flex items-center gap-3 rounded-full border border-dashed border-burgundy/40 bg-white px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy/70">
                <Instagram className="h-4 w-4" aria-hidden />
                Instagram — coming soon
              </span>
              <p className="text-xs text-muted-foreground">
                Our profile link will appear here once ELAYA&apos;s Instagram is live.
              </p>
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
