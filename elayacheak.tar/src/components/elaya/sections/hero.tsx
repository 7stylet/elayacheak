"use client";

import Image from "next/image";
import { ArrowRight, Sparkles } from "lucide-react";
import { useELAYA } from "@/lib/store";

export function Hero() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <section aria-label="ELAYA hero" className="relative overflow-hidden bg-cream">
      {/* decorative blobs */}
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 top-16 h-96 w-96 rounded-full bg-rose-soft/40 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 bottom-0 h-[28rem] w-[28rem] rounded-full bg-beige-soft blur-3xl"
      />

      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 pb-14 pt-10 sm:px-6 md:pb-20 md:pt-16 lg:grid-cols-2 lg:items-center lg:gap-16 lg:px-8">
        {/* Copy */}
        <div className="order-2 lg:order-1">
          <p className="eyebrow animate-fade-up text-burgundy/70">
            ELAYA · New Season
          </p>
          <h1
            className="display-1 animate-fade-up delay-100 mt-4 text-charcoal"
            style={{ animationDelay: "0.12s" }}
          >
            More Than a Bag.
            <br />
            <span className="italic text-burgundy">A Part of You.</span>
          </h1>
          <p
            className="animate-fade-up delay-200 mt-6 max-w-md text-[15px] leading-relaxed text-muted-foreground md:text-base"
            style={{ animationDelay: "0.22s" }}
          >
            Discover handbags that reflect your personality. From everyday
            essentials to personalized designs, find the perfect bag for every
            moment.
          </p>
          <div
            className="animate-fade-up delay-300 mt-9 flex flex-wrap items-center gap-4"
            style={{ animationDelay: "0.32s" }}
          >
            <button
              type="button"
              onClick={() => navigate({ view: "shop" })}
              className="group inline-flex items-center gap-3 rounded-full bg-burgundy px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground shadow-[0_10px_30px_rgba(104,45,59,0.25)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-burgundy-deep hover:shadow-[0_16px_40px_rgba(104,45,59,0.35)]"
            >
              Shop Collection
              <ArrowRight
                className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                aria-hidden
              />
            </button>
            <button
              type="button"
              onClick={() => navigate({ view: "customize" })}
              className="group inline-flex items-center gap-3 rounded-full border border-burgundy/35 bg-white/50 px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-burgundy backdrop-blur transition-all duration-300 hover:-translate-y-0.5 hover:border-burgundy hover:bg-white"
            >
              <Sparkles className="h-4 w-4 transition-transform duration-500 group-hover:rotate-12" aria-hidden />
              Create Your Own
            </button>
          </div>

          {/* trust row */}
          <div
            className="animate-fade-up delay-500 mt-12 flex flex-wrap gap-x-10 gap-y-4"
            style={{ animationDelay: "0.45s" }}
          >
            {[
              ["Student-friendly", "thoughtful pricing"],
              ["Personalized", "made just for you"],
              ["Cash on Delivery", "across Pakistan"],
            ].map(([title, sub]) => (
              <div key={title}>
                <p className="font-serif text-[15px] text-charcoal">{title}</p>
                <p className="text-xs text-muted-foreground">{sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Image */}
        <div className="relative order-1 lg:order-2">
          <div className="animate-fade-up relative mx-auto aspect-[3/4] w-full max-w-md overflow-hidden rounded-[2rem] shadow-[0_30px_80px_rgba(104,45,59,0.18)] lg:max-w-lg">
            <Image
              src="/images/hero.png"
              alt="Woman carrying an elegant ELAYA handbag"
              fill
              priority
              sizes="(max-width: 1024px) 90vw, 40vw"
              className="object-cover"
            />
            <div
              aria-hidden
              className="absolute inset-0 bg-gradient-to-t from-burgundy/10 via-transparent to-transparent"
            />
          </div>

          {/* floating card */}
          <div className="animate-float absolute -bottom-5 left-2 hidden rounded-2xl border border-border bg-white/90 px-5 py-4 shadow-xl backdrop-blur sm:block lg:-left-6">
            <p className="text-[10px] uppercase tracking-[0.24em] text-burgundy/70">
              Signature piece
            </p>
            <p className="mt-1 font-serif text-[15px] text-charcoal">
              Rosé Mini Tote · Rs 2,850
            </p>
            <button
              type="button"
              onClick={() => navigate({ view: "product", slug: "elaya-rose-mini-tote" })}
              className="link-underline mt-1 text-xs font-medium text-burgundy"
            >
              View the bag
            </button>
          </div>

          {/* small secondary image */}
          <div className="absolute -right-3 -top-5 hidden h-36 w-28 overflow-hidden rounded-2xl border-4 border-cream shadow-xl md:block lg:-right-8">
            <Image
              src="/images/hero-detail.png"
              alt=""
              fill
              priority
              loading="eager"
              sizes="112px"
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
