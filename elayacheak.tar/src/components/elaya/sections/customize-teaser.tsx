"use client";

import Image from "next/image";
import { ArrowRight, Gift, Palette, PenLine } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { Reveal } from "@/components/elaya/reveal";

const STEPS = [
  {
    icon: Palette,
    title: "Pick your style & colour",
    text: "Five silhouettes in seven shades — from blush to burgundy.",
  },
  {
    icon: PenLine,
    title: "Add your personal touch",
    text: "Initials, a short name, decorative details or a message.",
  },
  {
    icon: Gift,
    title: "Unbox your story",
    text: "Optional gift packaging makes every reveal unforgettable.",
  },
];

export function CustomizeTeaser() {
  const navigate = useELAYA((s) => s.navigate);

  return (
    <section aria-labelledby="customize-heading" className="relative overflow-hidden py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-[2rem] bg-beige-soft shadow-[0_20px_60px_rgba(104,45,59,0.10)]">
          <div className="grid lg:grid-cols-2">
            {/* Copy */}
            <div className="order-2 flex flex-col justify-center p-8 md:p-12 lg:order-1 lg:p-16">
              <Reveal>
                <p className="eyebrow text-burgundy/70">The ELAYA Atelier</p>
                <h2 id="customize-heading" className="display-2 mt-3 text-charcoal">
                  Your Bag.
                  <br />
                  <span className="italic text-burgundy">Your Personality.</span>
                </h2>
                <p className="mt-5 max-w-md text-[15px] leading-relaxed text-muted-foreground">
                  Make it yours. Choose the details that turn your handbag into
                  something personal — colours, initials, decorative touches and
                  gift-ready packaging.
                </p>
              </Reveal>

              <div className="mt-8 space-y-5">
                {STEPS.map((step, i) => (
                  <Reveal key={step.title} delay={0.1 + i * 0.08}>
                    <div className="flex items-start gap-4">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-burgundy text-primary-foreground shadow-md">
                        <step.icon className="h-5 w-5" aria-hidden />
                      </span>
                      <div>
                        <p className="font-serif text-[17px] text-charcoal">{step.title}</p>
                        <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                          {step.text}
                        </p>
                      </div>
                    </div>
                  </Reveal>
                ))}
              </div>

              <Reveal delay={0.3} className="mt-10">
                <button
                  type="button"
                  onClick={() => navigate({ view: "customize" })}
                  className="group inline-flex items-center gap-3 rounded-full bg-charcoal px-8 py-4 text-xs font-semibold uppercase tracking-[0.2em] text-cream transition-all duration-300 hover:-translate-y-0.5 hover:bg-burgundy hover:shadow-[0_14px_36px_rgba(104,45,59,0.3)]"
                >
                  Start Designing
                  <ArrowRight
                    className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                    aria-hidden
                  />
                </button>
                <p className="mt-3 text-xs text-muted-foreground">
                  From Rs 2,850 + personal touches
                </p>
              </Reveal>
            </div>

            {/* Image */}
            <div className="relative order-1 min-h-[280px] lg:order-2 lg:min-h-[560px]">
              <Image
                src="/images/customize-banner.png"
                alt="Handbag customization atelier with gold charms and ribbons"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div
                aria-hidden
                className="absolute inset-0 bg-gradient-to-r from-beige-soft/60 via-transparent to-transparent"
              />
              <div className="absolute bottom-6 right-6 rounded-2xl bg-white/90 px-5 py-4 shadow-lg backdrop-blur">
                <p className="text-[10px] uppercase tracking-[0.22em] text-burgundy/70">
                  Live preview
                </p>
                <p className="mt-1 font-serif text-[15px] text-charcoal">
                  See your design as you build it
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
