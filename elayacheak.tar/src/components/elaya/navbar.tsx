"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import {
  ChevronDown,
  Heart,
  Menu,
  Search,
  ShoppingBag,
  Sparkles,
  User,
  X,
} from "lucide-react";
import { useELAYA, cartCount, ViewName } from "@/lib/store";
import { COLLECTIONS } from "@/lib/products";
import { SITE_CONFIG } from "@/lib/config";
import { cn } from "@/lib/utils";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const NAV_LINKS: { label: string; view: ViewName }[] = [
  { label: "Home", view: "home" },
  { label: "Shop All", view: "shop" },
  { label: "Customize Your Bag", view: "customize" },
  { label: "About Us", view: "about" },
  { label: "Contact", view: "contact" },
];

function Wordmark({ onClick }: { onClick?: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="ELAYA — go to homepage"
      className="flex flex-col items-start leading-none focus-visible:outline-2 focus-visible:outline-burgundy rounded-sm"
    >
      <span className="font-serif text-[26px] md:text-[30px] font-semibold tracking-[0.18em] text-burgundy">
        ELAYA
      </span>
      <span className="hidden sm:block text-[8px] uppercase tracking-[0.42em] text-muted-foreground mt-1">
        Handcrafted Style
      </span>
    </button>
  );
}

function CountBadge({ count }: { count: number }) {
  if (count <= 0) return null;
  return (
    <span className="absolute -right-1.5 -top-1.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-burgundy px-1 text-[10px] font-semibold text-primary-foreground">
      {count > 9 ? "9+" : count}
    </span>
  );
}

/**
 * false during SSR + hydration render, true afterwards — prevents
 * localStorage-derived badges from causing hydration mismatches.
 */
const emptySubscribe = () => () => {};
function useHydrated() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

export function Navbar() {
  const navigate = useELAYA((s) => s.navigate);
  const route = useELAYA((s) => s.route);
  const setCartOpen = useELAYA((s) => s.setCartOpen);
  const setSearchOpen = useELAYA((s) => s.setSearchOpen);
  const cart = useELAYA((s) => s.cart);
  const wishlist = useELAYA((s) => s.wishlist);
  const menuOpen = useELAYA((s) => s.menuOpen);
  const setMenuOpen = useELAYA((s) => s.setMenuOpen);

  const [scrolled, setScrolled] = useState(false);
  const [collectionsOpen, setCollectionsOpen] = useState(false);
  const hydrated = useHydrated();

  const count = hydrated ? cartCount(cart) : 0;
  const wishlistCount = hydrated ? wishlist.length : 0;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // lock body scroll when mobile menu open
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const isActive = (view: ViewName) => {
    if (view === "shop") return route.view === "shop" || route.view === "product";
    if (view === "home") return route.view === "home";
    return route.view === view;
  };

  return (
    <>
      {/* Announcement bar */}
      <div className="relative overflow-hidden bg-burgundy text-primary-foreground">
        <div className="flex w-max animate-marquee py-2 whitespace-nowrap">
          {[0, 1].map((copy) => (
            <div key={copy} className="flex items-center" aria-hidden={copy === 1}>
              {[
                "Free delivery on orders above Rs 5,000",
                "Personalized bags — made just for you",
                "Cash on Delivery available across Pakistan",
                "Student-friendly prices, boutique quality",
              ].map((text) => (
                <span
                  key={text}
                  className="mx-8 inline-flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em]"
                >
                  <Sparkles className="h-3 w-3" aria-hidden />
                  {text}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Main navbar */}
      <header
        className={cn(
          "sticky top-0 z-50 w-full border-b transition-all duration-500",
          scrolled
            ? "border-border bg-cream/90 shadow-[0_6px_24px_rgba(104,45,59,0.07)] backdrop-blur-md"
            : "border-transparent bg-cream"
        )}
      >
        <nav
          aria-label="Main navigation"
          className="mx-auto flex h-[68px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8"
        >
          {/* Left: wordmark */}
          <Wordmark onClick={() => navigate({ view: "home" })} />

          {/* Center: links (desktop) */}
          <ul className="hidden lg:flex items-center gap-7">
            {NAV_LINKS.slice(0, 2).map((link) => (
              <li key={link.label}>
                <button
                  type="button"
                  onClick={() => navigate({ view: link.view })}
                  data-active={isActive(link.view)}
                  className={cn(
                    "link-underline text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal/80 transition-colors hover:text-burgundy",
                    isActive(link.view) && "text-burgundy"
                  )}
                >
                  {link.label}
                </button>
              </li>
            ))}

            {/* Collections dropdown */}
            <li
              className="relative"
              onMouseEnter={() => setCollectionsOpen(true)}
              onMouseLeave={() => setCollectionsOpen(false)}
            >
              <button
                type="button"
                aria-expanded={collectionsOpen}
                aria-haspopup="true"
                onClick={() => navigate({ view: "shop" })}
                className={cn(
                  "link-underline flex items-center gap-1 text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal/80 transition-colors hover:text-burgundy",
                  route.view === "shop" && "text-burgundy"
                )}
              >
                Collections
                <ChevronDown className="h-3.5 w-3.5 transition-transform duration-300" aria-hidden />
              </button>
              <div
                className={cn(
                  "absolute left-1/2 top-full z-50 w-72 -translate-x-1/2 pt-4 transition-all duration-300",
                  collectionsOpen
                    ? "visible translate-y-0 opacity-100"
                    : "invisible -translate-y-2 opacity-0"
                )}
              >
                <div className="overflow-hidden rounded-2xl border border-border bg-popover shadow-xl">
                  {COLLECTIONS.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setCollectionsOpen(false);
                        navigate({ view: "shop", collection: c.id });
                      }}
                      className="flex w-full flex-col gap-0.5 px-5 py-3.5 text-left transition-colors hover:bg-secondary"
                    >
                      <span className="font-serif text-[15px] text-charcoal">{c.name}</span>
                      <span className="line-clamp-1 text-xs text-muted-foreground">
                        {c.shortDescription}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </li>

            {NAV_LINKS.slice(2).map((link) => (
              <li key={link.label}>
                <button
                  type="button"
                  onClick={() => navigate({ view: link.view })}
                  data-active={isActive(link.view)}
                  className={cn(
                    "link-underline text-[13px] font-medium uppercase tracking-[0.14em] text-charcoal/80 transition-colors hover:text-burgundy",
                    isActive(link.view) && "text-burgundy"
                  )}
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>

          {/* Right: icons */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              aria-label="Search products"
              onClick={() => setSearchOpen(true)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-charcoal transition-colors hover:bg-secondary hover:text-burgundy"
            >
              <Search className="h-[18px] w-[18px]" aria-hidden />
            </button>

            {/* Account popover — honest placeholder */}
            <Popover>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  aria-label="Account"
                  className="hidden sm:flex h-10 w-10 items-center justify-center rounded-full text-charcoal transition-colors hover:bg-secondary hover:text-burgundy"
                >
                  <User className="h-[18px] w-[18px]" aria-hidden />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-64 rounded-2xl p-4">
                <p className="font-serif text-[15px] text-charcoal">Customer Accounts</p>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
                  Online accounts are coming soon. For order updates, reach us any
                  time — we reply quickly.
                </p>
                <button
                  type="button"
                  onClick={() => navigate({ view: "contact" })}
                  className="mt-3 w-full rounded-full bg-burgundy px-4 py-2 text-xs font-medium uppercase tracking-[0.16em] text-primary-foreground transition-colors hover:bg-burgundy-deep"
                >
                  Contact Us
                </button>
              </PopoverContent>
            </Popover>

            <button
              type="button"
              aria-label={`Wishlist, ${wishlistCount} items`}
              onClick={() => navigate({ view: "wishlist" })}
              className="relative flex h-10 w-10 items-center justify-center rounded-full text-charcoal transition-colors hover:bg-secondary hover:text-burgundy"
            >
              <Heart className="h-[18px] w-[18px]" aria-hidden />
              <CountBadge count={wishlistCount} />
            </button>

            <button
              type="button"
              aria-label={`Shopping bag, ${count} items`}
              onClick={() => setCartOpen(true)}
              className="relative flex h-10 w-10 items-center justify-center rounded-full text-charcoal transition-colors hover:bg-secondary hover:text-burgundy"
            >
              <ShoppingBag className="h-[18px] w-[18px]" aria-hidden />
              <CountBadge count={count} />
            </button>

            <button
              type="button"
              aria-label="Open menu"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen(true)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-charcoal transition-colors hover:bg-secondary hover:text-burgundy lg:hidden"
            >
              <Menu className="h-5 w-5" aria-hidden />
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile menu overlay */}
      <div
        className={cn(
          "fixed inset-0 z-[60] lg:hidden transition-opacity duration-300",
          menuOpen ? "visible opacity-100" : "invisible opacity-0"
        )}
        role="dialog"
        aria-modal="true"
        aria-label="Mobile menu"
      >
        <div
          className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm"
          onClick={() => setMenuOpen(false)}
        />
        <div
          className={cn(
            "absolute inset-y-0 left-0 flex w-[86%] max-w-sm flex-col bg-cream shadow-2xl transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
            menuOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <span className="font-serif text-xl font-semibold tracking-[0.18em] text-burgundy">
              ELAYA
            </span>
            <button
              type="button"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
              className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-secondary"
            >
              <X className="h-5 w-5" aria-hidden />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-5 py-6">
            <ul className="space-y-1">
              {NAV_LINKS.map((link, i) => (
                <li key={link.label}>
                  <button
                    type="button"
                    onClick={() => navigate({ view: link.view })}
                    style={{ transitionDelay: menuOpen ? `${i * 40}ms` : "0ms" }}
                    className={cn(
                      "w-full py-3 text-left font-serif text-2xl text-charcoal transition-all duration-500",
                      menuOpen ? "translate-x-0 opacity-100" : "translate-x-4 opacity-0",
                      isActive(link.view) && "text-burgundy"
                    )}
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>

            <p className="eyebrow mt-8 mb-3 text-muted-foreground">Collections</p>
            <ul className="space-y-1">
              {COLLECTIONS.map((c) => (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => navigate({ view: "shop", collection: c.id })}
                    className="w-full rounded-xl bg-secondary/60 px-4 py-3 text-left text-[14px] text-charcoal transition-colors hover:bg-rose-soft/50"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>

            <p className="eyebrow mt-8 mb-3 text-muted-foreground">Customer Care</p>
            <ul className="space-y-1 text-[14px]">
              {(
                [
                  ["FAQs", "faq"],
                  ["Shipping Information", "shipping"],
                  ["Returns & Exchanges", "returns"],
                  ["Wishlist", "wishlist"],
                ] as const
              ).map(([label, view]) => (
                <li key={view}>
                  <button
                    type="button"
                    onClick={() => navigate({ view: view as ViewName })}
                    className="w-full py-2 text-left text-charcoal/80 hover:text-burgundy"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="border-t border-border px-5 py-4">
            <p className="text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
              {SITE_CONFIG.tagline}
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
