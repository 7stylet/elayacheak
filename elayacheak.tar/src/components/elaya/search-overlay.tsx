"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { Search, X } from "lucide-react";
import { useELAYA } from "@/lib/store";
import { PRODUCTS, formatPKRDisplay } from "@/lib/product-utils";
import { cn } from "@/lib/utils";

export function SearchOverlay() {
  const setSearchOpen = useELAYA((s) => s.setSearchOpen);
  const navigate = useELAYA((s) => s.navigate);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 120);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      clearTimeout(t);
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [setSearchOpen]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.style.toLowerCase().includes(q) ||
        p.shortDescription.toLowerCase().includes(q) ||
        p.colors.some((c) => c.name.toLowerCase().includes(q))
    ).slice(0, 6);
  }, [query]);

  return (
    <div
      className="fixed inset-0 z-[70] flex flex-col bg-cream/95 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label="Search"
    >
      <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col px-5 pt-[12vh]">
        <button
          type="button"
          aria-label="Close search"
          onClick={() => setSearchOpen(false)}
          className="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full border border-border bg-white/70 text-charcoal transition-colors hover:bg-white"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>

        <p className="eyebrow text-center text-burgundy/70">Search ELAYA</p>

        <div className="relative mt-5">
          <Search
            className="absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Try “tote”, “burgundy”, “gift”…"
            aria-label="Search products"
            className="w-full rounded-full border border-border bg-white py-4 pl-14 pr-5 font-serif text-lg text-charcoal shadow-sm outline-none transition-shadow placeholder:text-muted-foreground/60 focus:border-rose-dust focus:shadow-[0_0_0_4px_rgba(217,166,160,0.2)]"
          />
        </div>

        {/* Results */}
        <div className="scrollbar-thin mt-6 flex-1 overflow-y-auto pb-10">
          {query.trim() === "" ? (
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Popular searches
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {["Tote", "Mini", "Burgundy", "Gift", "Personalized", "Clutch"].map(
                  (term) => (
                    <button
                      key={term}
                      type="button"
                      onClick={() => setQuery(term)}
                      className="rounded-full border border-border bg-white px-4 py-2 text-sm text-charcoal transition-colors hover:border-rose-dust hover:text-burgundy"
                    >
                      {term}
                    </button>
                  )
                )}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="mt-10 text-center">
              <p className="font-serif text-xl text-charcoal">No matches found</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Try a different word — or browse the full collection instead.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchOpen(false);
                  navigate({ view: "shop" });
                }}
                className="mt-5 rounded-full bg-burgundy px-6 py-2.5 text-xs font-medium uppercase tracking-[0.16em] text-primary-foreground hover:bg-burgundy-deep"
              >
                Shop All
              </button>
            </div>
          ) : (
            <ul className="space-y-2">
              {results.map((p) => (
                <li key={p.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchOpen(false);
                      navigate({ view: "product", slug: p.slug });
                    }}
                    className={cn(
                      "flex w-full items-center gap-4 rounded-2xl border border-transparent bg-white/70 p-3 text-left",
                      "transition-all hover:border-rose-dust/50 hover:bg-white hover:shadow-sm"
                    )}
                  >
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-beige-soft">
                      <Image
                        src={p.images[0]}
                        alt=""
                        fill
                        sizes="64px"
                        className="object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-serif text-[15px] text-charcoal">
                        {p.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {p.style} · {p.colors.map((c) => c.name).join(", ")}
                      </p>
                    </div>
                    <p className="text-sm font-medium text-burgundy">
                      {formatPKRDisplay(p.price)}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
