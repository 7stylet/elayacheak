import type { Metadata, Viewport } from "next";
import { Playfair_Display, Jost } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
});

const jost = Jost({
  variable: "--font-jost",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "ELAYA — Carry Your Style. Express Your Story.",
    template: "%s | ELAYA",
  },
  description:
    "ELAYA is a Pakistani women's handbag brand offering elegant everyday bags, chic classics, personalized designs and gift-ready handbags — thoughtfully priced for university students and young women.",
  keywords: [
    "ELAYA",
    "handbags Pakistan",
    "women bags",
    "personalized handbags",
    "customized bags",
    "university bags",
    "gift bags Pakistan",
    "affordable luxury bags",
  ],
  authors: [{ name: "ELAYA" }],
  openGraph: {
    title: "ELAYA — More Than a Bag. A Part of You.",
    description:
      "Discover handbags that reflect your personality. From everyday essentials to personalized designs, find the perfect bag for every moment.",
    siteName: "ELAYA",
    type: "website",
    locale: "en_PK",
  },
  twitter: {
    card: "summary_large_image",
    title: "ELAYA — Carry Your Style. Express Your Story.",
    description:
      "Elegant, affordable handbags and personalized designs for young women in Pakistan.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#F8F3ED",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${playfair.variable} ${jost.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
