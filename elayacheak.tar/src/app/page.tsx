import { ELAYAApp } from "@/components/elaya/elaya-app";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "OnlineStore",
  name: "ELAYA",
  slogan: "Carry Your Style. Express Your Story.",
  description:
    "Women's hand-carry bags and customized handbags — elegant, affordable, made for young women in Pakistan.",
  paymentAccepted: "Cash on Delivery, Bank Transfer",
  currenciesAccepted: "PKR",
  areaServed: "Pakistan",
};

export default function Page() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ELAYAApp />
    </>
  );
}
