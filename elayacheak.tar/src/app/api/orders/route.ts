import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const orderSchema = z.object({
  customer: z.object({
    name: z.string().trim().min(3).max(80),
    phone: z
      .string()
      .trim()
      .regex(/^(\+?92|0)?[0-9]{10}$/, "Invalid Pakistani phone number"),
    email: z.string().trim().email().optional().or(z.literal("")),
    city: z.string().trim().min(2).max(60),
    address: z.string().trim().min(10).max(400),
    notes: z.string().trim().max(400).optional().or(z.literal("")),
  }),
  paymentMethod: z.enum(["cod", "bank_transfer"]),
  items: z
    .array(
      z.object({
        productId: z.string().max(60),
        name: z.string().max(160),
        color: z.string().max(60),
        qty: z.number().int().min(1).max(9),
        unitPrice: z.number().int().min(0),
        customization: z
          .object({
            styleName: z.string().max(60).optional(),
            colorName: z.string().max(60).optional(),
            initials: z.string().max(24).optional(),
            message: z.string().max(120).optional(),
            decor: z.array(z.string().max(60)).max(10).optional(),
            accessories: z.array(z.string().max(60)).max(10).optional(),
            packaging: z.string().max(60).optional(),
          })
          .nullish(),
      })
    )
    .min(1)
    .max(30),
  subtotal: z.number().int().min(0),
  deliveryFee: z.number().int().min(0),
  total: z.number().int().min(0),
});

function generateOrderNumber(): string {
  const now = new Date();
  const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(
    now.getDate()
  ).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `ELA-${stamp}-${rand}`;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = orderSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Some order details are invalid. Please review the checkout form." },
        { status: 400 }
      );
    }

    const data = parsed.data;
    const orderNumber = generateOrderNumber();

    const order = await db.order.create({
      data: {
        orderNumber,
        customerName: data.customer.name,
        phone: data.customer.phone,
        email: data.customer.email || null,
        city: data.customer.city,
        address: data.customer.address,
        notes: data.customer.notes || null,
        paymentMethod:
          data.paymentMethod === "cod" ? "Cash on Delivery" : "Bank Transfer",
        subtotal: data.subtotal,
        deliveryFee: data.deliveryFee,
        total: data.total,
        itemsJson: JSON.stringify(data.items),
        status: "pending",
      },
    });

    return NextResponse.json({
      ok: true,
      orderNumber: order.orderNumber,
      placedAt: order.createdAt.toISOString(),
    });
  } catch (error) {
    console.error("[orders] failed to save order:", error);
    return NextResponse.json(
      { error: "We couldn't save your order. Please try again in a moment." },
      { status: 500 }
    );
  }
}
