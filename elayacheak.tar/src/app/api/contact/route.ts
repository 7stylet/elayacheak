import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160),
  message: z.string().trim().min(10).max(1000),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = contactSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please review your details — some fields need attention." },
        { status: 400 }
      );
    }

    await db.contactMessage.create({ data: parsed.data });

    return NextResponse.json({
      ok: true,
      message: "Message received — we'll reply to your email within 24 hours, Insha'Allah.",
    });
  } catch (error) {
    console.error("[contact] message failed:", error);
    return NextResponse.json(
      { error: "Message could not be sent. Please try again." },
      { status: 500 }
    );
  }
}
