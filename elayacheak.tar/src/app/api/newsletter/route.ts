import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const subscribeSchema = z.object({
  email: z.string().trim().email().max(160),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = subscribeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    const email = parsed.data.email.toLowerCase();

    const existing = await db.newsletterSubscriber.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json({
        ok: true,
        message: "You're already on the list — welcome back!",
        alreadySubscribed: true,
      });
    }

    await db.newsletterSubscriber.create({ data: { email } });

    return NextResponse.json({
      ok: true,
      message: "You're on the list. Welcome to ELAYA.",
    });
  } catch (error) {
    console.error("[newsletter] subscription failed:", error);
    return NextResponse.json(
      { error: "Subscription could not be processed. Please try again." },
      { status: 500 }
    );
  }
}
