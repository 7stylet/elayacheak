/**
 * ─────────────────────────────────────────────────────────────
 *  ELAYA — PRODUCT CATALOGUE (sample data)
 *  All names, prices, images and availability are EDITABLE
 *  sample placeholders for development. Update them freely.
 * ─────────────────────────────────────────────────────────────
 */

export type CollectionId =
  | "everyday-elegance"
  | "chic-classic"
  | "personalized"
  | "gift-collection";

export interface ColorOption {
  name: string;
  hex: string;
  /** optional price delta when this colour is selected */
  priceDelta?: number;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  price: number;
  /** original price to show as a strike-through (optional) */
  compareAtPrice?: number;
  images: string[];
  shortDescription: string;
  description: string;
  material: string;
  dimensions: string;
  care: string;
  colors: ColorOption[];
  collection: CollectionId;
  /** e.g. "Tote", "Top Handle", "Clutch" — used by shop filters */
  style: string;
  badge?: "New Arrival" | "Best Seller";
  inStock: boolean;
  rating: number;
  reviewCount: number;
  customizable: boolean;
  features: string[];
  /** smaller integer = shown earlier under "Featured" sorting */
  featuredRank: number;
  /** ISO date string used by "Newest Arrivals" sorting */
  addedAt: string;
}

export interface Collection {
  id: CollectionId;
  name: string;
  image: string;
  shortDescription: string;
  longDescription: string;
}

export const COLLECTIONS: Collection[] = [
  {
    id: "everyday-elegance",
    name: "Everyday Elegance",
    image: "/images/col-everyday.png",
    shortDescription:
      "Minimal, practical bags for university, college, shopping and every day in between.",
    longDescription:
      "Lightweight, roomy and easy to carry all day — these bags are designed around real student life: lectures, library hours, café catch-ups and everything else your day holds.",
  },
  {
    id: "chic-classic",
    name: "Chic & Classic",
    image: "/images/col-chic.png",
    shortDescription:
      "Elegant handbags for formal events, dinners, parties and special occasions.",
    longDescription:
      "Refined silhouettes, richer tones and polished hardware. These are the bags you reach for when the invitation says dressed up — dinners, weddings, convocations and celebrations.",
  },
  {
    id: "personalized",
    name: "Personalized by ELAYA",
    image: "/images/col-personalized.png",
    shortDescription:
      "Customized bags with names, initials, colours, decorative details and personal messages.",
    longDescription:
      "Your bag, your story. Add initials, choose the colour palette, pick decorative details and write a message that makes it unmistakably yours — or someone special's.",
  },
  {
    id: "gift-collection",
    name: "Gift Collection",
    image: "/images/col-gift.png",
    shortDescription:
      "Beautiful handbags for birthdays, friendship gifts, celebrations and special moments.",
    longDescription:
      "Thoughtfully packaged and ready to give. Each gift-ready bag arrives in elegant packaging, because the moment of unwrapping should feel just as special as what's inside.",
  },
];

const C = {
  blush: "#E8C4BE",
  roseDust: "#D9A6A0",
  burgundy: "#682D3B",
  black: "#2B2626",
  cream: "#F1E7DA",
  taupe: "#B9A48E",
  sage: "#A8B5A2",
  gold: "#C9A24B",
};

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    slug: "elaya-rose-mini-tote",
    name: "ELAYA Rosé Mini Tote",
    price: 2850,
    compareAtPrice: 3350,
    images: ["/images/product-01a.png", "/images/product-01b.png"],
    shortDescription:
      "A petite structured tote in blush pebbled leather — small enough to stay light, big enough for your essentials.",
    description:
      "The Rosé Mini Tote is the everyday companion for days that move fast. Its structured silhouette keeps your phone, wallet, compact and keys neatly organised, while the soft pebbled finish and gold-tone clasp add a quietly luxurious touch. Carry it by the top handles to a morning lecture or let it sit on your arm through an evening out — it adapts without ever looking ordinary.",
    material: "Premium vegan pebbled leather, gold-tone hardware, lined interior",
    dimensions: "24 cm (W) × 17 cm (H) × 10 cm (D), handle drop: 8 cm",
    care:
      "Wipe gently with a soft dry cloth. Keep away from prolonged sunlight and moisture. Store in the dust bag provided.",
    colors: [
      { name: "Blush Pink", hex: C.blush },
      { name: "Cream", hex: C.cream },
      { name: "Black", hex: C.black, priceDelta: 100 },
    ],
    collection: "everyday-elegance",
    style: "Mini Tote",
    badge: "New Arrival",
    inStock: true,
    rating: 4.8,
    reviewCount: 34,
    customizable: false,
    features: [
      "Fits a 7.9-inch tablet and everyday essentials",
      "Interior zip pocket for cards and cash",
      "Magnetic snap closure",
    ],
    featuredRank: 1,
    addedAt: "2026-09-14",
  },
  {
    id: "p2",
    slug: "elaya-classic-charm",
    name: "ELAYA Classic Charm",
    price: 3950,
    images: ["/images/product-02a.png", "/images/product-02b.png"],
    shortDescription:
      "A structured top-handle bag in deep burgundy with a gold turn-lock — quiet luxury for formal days.",
    description:
      "Classic Charm is ELAYA's love letter to timeless design. The deep burgundy body pairs with a satisfying gold turn-lock and hand-finished stitching, creating a bag that feels far above its price. Its firm structure holds its shape from morning convocations to late-night dinners, and the convertible strap lets it move from hand-carry to shoulder in seconds.",
    material: "Smooth vegan leather, gold-tone turn-lock, suede-feel lining",
    dimensions: "26 cm (W) × 19 cm (H) × 11 cm (D), detachable shoulder strap",
    care:
      "Wipe with a soft dry cloth. Avoid overloading to maintain structure. Store upright in the dust bag.",
    colors: [
      { name: "Burgundy", hex: C.burgundy },
      { name: "Black", hex: C.black },
      { name: "Cream", hex: C.cream },
    ],
    collection: "chic-classic",
    style: "Top Handle",
    badge: "Best Seller",
    inStock: true,
    rating: 4.9,
    reviewCount: 52,
    customizable: false,
    features: [
      "Convertible: top-handle or shoulder strap",
      "Gold turn-lock closure",
      "Holds its structured shape",
    ],
    featuredRank: 2,
    addedAt: "2026-08-02",
  },
  {
    id: "p3",
    slug: "elaya-everyday-muse",
    name: "ELAYA Everyday Muse",
    price: 3450,
    images: ["/images/product-03a.png", "/images/product-03b.png"],
    shortDescription:
      "A spacious taupe tote built for real days — laptop-friendly, library-ready, endlessly practical.",
    description:
      "Everyday Muse was designed around the rhythm of student life. The roomy interior swallows notebooks, a 13-inch laptop, a water bottle and a cardigan without losing its shape, while long shoulder straps sit comfortably even when fully loaded. A soft suede-feel lining and interior pocket keep the small things exactly where you left them.",
    material: "Smooth vegan leather, reinforced base, soft polyester lining",
    dimensions: "38 cm (W) × 28 cm (H) × 13 cm (D), fits up to 13-inch laptops",
    care:
      "Spot clean with a slightly damp cloth and air dry. Do not machine wash. Store flat when not in use.",
    colors: [
      { name: "Taupe", hex: C.taupe },
      { name: "Black", hex: C.black },
      { name: "Blush Pink", hex: C.blush },
    ],
    collection: "everyday-elegance",
    style: "Tote",
    badge: "Best Seller",
    inStock: true,
    rating: 4.7,
    reviewCount: 88,
    customizable: false,
    features: [
      "Fits 13-inch laptop and A4 folders",
      "Reinforced base for heavy days",
      "Interior slip + zip pockets",
    ],
    featuredRank: 3,
    addedAt: "2026-07-19",
  },
  {
    id: "p4",
    slug: "elaya-blush-carryall",
    name: "ELAYA Blush Carryall",
    price: 4250,
    images: ["/images/product-04a.png", "/images/product-04b.png"],
    shortDescription:
      "A soft, slouchy carryall in dusty rose — effortless volume with a romantic finish.",
    description:
      "Blush Carryall brings an easy, unstructured elegance to your busiest days. Its supple body folds gently over your arm, expanding to carry shopping, assignments and everything in between, then softens into a romantic silhouette when empty. The magnetic snap keeps everything secure without any fuss.",
    material: "Buttery-soft vegan leather, magnetic snap closure, cotton lining",
    dimensions: "42 cm (W) × 30 cm (H) × 14 cm (D)",
    care:
      "Wipe with a soft dry cloth. Reshape and stuff with paper when storing. Avoid sharp surfaces.",
    colors: [
      { name: "Dusty Rose", hex: C.roseDust },
      { name: "Cream", hex: C.cream },
      { name: "Black", hex: C.black, priceDelta: 100 },
    ],
    collection: "everyday-elegance",
    style: "Tote",
    inStock: true,
    rating: 4.6,
    reviewCount: 41,
    customizable: false,
    features: [
      "Expands to carry a full day's essentials",
      "Magnetic snap closure",
      "Soft, lightweight feel",
    ],
    featuredRank: 4,
    addedAt: "2026-08-25",
  },
  {
    id: "p5",
    slug: "elaya-midnight-elegance",
    name: "ELAYA Midnight Elegance",
    price: 4950,
    images: ["/images/product-05a.png", "/images/product-05b.png"],
    shortDescription:
      "A black evening bag with a gold chain strap — the finishing touch for nights that matter.",
    description:
      "Midnight Elegance is the little black dress of handbags. A quilted satin-matte body meets a delicate gold chain that drapes beautifully over the shoulder or tucks inside for a clutch silhouette. Sized precisely for phone, lipstick and cards, it is made for dinners, mehndis, and every celebration in between.",
    material: "Satin-matte vegan leather, quilted panel, gold-tone chain strap",
    dimensions: "22 cm (W) × 14 cm (H) × 6 cm (D), chain drop: 55 cm",
    care:
      "Handle with clean dry hands. Store flat in the box provided to protect the chain finish.",
    colors: [
      { name: "Black", hex: C.black },
      { name: "Burgundy", hex: C.burgundy, priceDelta: 150 },
    ],
    collection: "chic-classic",
    style: "Clutch",
    badge: "New Arrival",
    inStock: true,
    rating: 4.9,
    reviewCount: 27,
    customizable: false,
    features: [
      "Convertible clutch or shoulder wear",
      "Quilted satin-matte finish",
      "Card slots inside the flap",
    ],
    featuredRank: 5,
    addedAt: "2026-09-28",
  },
  {
    id: "p6",
    slug: "elaya-personalized-initial-bag",
    name: "ELAYA Personalized Initial Bag",
    price: 3650,
    images: ["/images/product-06a.png", "/images/product-06b.png"],
    shortDescription:
      "A cream crossbody with a gold initial charm — add a name or initials to make it truly yours.",
    description:
      "The Personalized Initial Bag turns a beautiful everyday crossbody into something no one else owns. Choose your colour, add up to three initials or a short name in gold-tone lettering, and we finish it with a delicately attached charm. It makes a heartfelt gift for birthdays, friendships and graduations — or a daily reminder that your story is worth carrying.",
    material: "Smooth vegan leather, gold-tone initial charm, adjustable strap",
    dimensions: "23 cm (W) × 16 cm (H) × 8 cm (D), adjustable strap: 120 cm",
    care:
      "Wipe gently with a soft dry cloth. Take care not to scratch the charm lettering. Store in the dust bag.",
    colors: [
      { name: "Cream", hex: C.cream },
      { name: "Blush Pink", hex: C.blush },
      { name: "Burgundy", hex: C.burgundy },
      { name: "Black", hex: C.black },
    ],
    collection: "personalized",
    style: "Crossbody",
    badge: "Best Seller",
    inStock: true,
    rating: 5.0,
    reviewCount: 63,
    customizable: true,
    features: [
      "Personalize with up to 3 initials or a short name",
      "Adjustable crossbody strap",
      "Gift-ready packaging included",
    ],
    featuredRank: 6,
    addedAt: "2026-08-10",
  },
  {
    id: "p7",
    slug: "elaya-soft-luxe-tote",
    name: "ELAYA Soft Luxe Tote",
    price: 4650,
    images: ["/images/product-07a.png", "/images/product-07b.png"],
    shortDescription:
      "A cream pebbled-leather tote with gold zip details — minimal design, maximum polish.",
    description:
      "Soft Luxe is for the woman who prefers her luxury quiet. The pebbled cream body, tonal stitching and gold zip pulls create a bag that pairs with everything from kurtas to co-ord sets. A structured rim keeps the opening upright and easy to pack, making it a favourite for uni-to-internship days.",
    material: "Pebbled vegan leather, gold-tone zips, structured rim, lined interior",
    dimensions: "36 cm (W) × 26 cm (H) × 12 cm (D)",
    care:
      "Wipe with a soft dry cloth. Condition occasionally with a vegan-leather balm. Store in the dust bag.",
    colors: [
      { name: "Cream", hex: C.cream },
      { name: "Blush Pink", hex: C.blush },
      { name: "Sage", hex: C.sage, priceDelta: 150 },
    ],
    collection: "everyday-elegance",
    style: "Tote",
    inStock: true,
    rating: 4.8,
    reviewCount: 39,
    customizable: false,
    features: [
      "Structured rim keeps the opening upright",
      "Gold-tone zip closures",
      "Detachable inner pouch",
    ],
    featuredRank: 7,
    addedAt: "2026-09-05",
  },
  {
    id: "p8",
    slug: "elaya-signature-gift-bag",
    name: "ELAYA Signature Gift Bag",
    price: 5450,
    images: ["/images/product-08a.png", "/images/product-08b.png"],
    shortDescription:
      "Our signature handbag in gift-ready packaging — a complete present for someone unforgettably special.",
    description:
      "The Signature Gift Bag is ELAYA at its most thoughtful. A structured dusty-rose handbag arrives nestled in cream tissue inside our signature gift box, tied with a satin ribbon and accompanied by a gift card. Choose to add a personalised message or initials to make the unwrapping moment truly hers — birthdays, friendship anniversaries and milestones made memorable.",
    material: "Smooth vegan leather, gold-tone hardware, signature gift packaging",
    dimensions: "28 cm (W) × 20 cm (H) × 12 cm (D)",
    care:
      "Wipe with a soft dry cloth. Retain the gift box for storage. Keep ribbons away from small children.",
    colors: [
      { name: "Dusty Rose", hex: C.roseDust },
      { name: "Burgundy", hex: C.burgundy },
    ],
    collection: "gift-collection",
    style: "Top Handle",
    badge: "New Arrival",
    inStock: true,
    rating: 4.9,
    reviewCount: 46,
    customizable: true,
    features: [
      "Signature gift box with ribbon and card",
      "Optional personalised message (+ Rs 400)",
      "Gold-tone hardware",
    ],
    featuredRank: 8,
    addedAt: "2026-10-01",
  },
];

export function getProductBySlug(slug: string): Product | undefined {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function getRelatedProducts(product: Product, limit = 4): Product[] {
  const sameCollection = PRODUCTS.filter(
    (p) => p.id !== product.id && p.collection === product.collection
  );
  const others = PRODUCTS.filter(
    (p) => p.id !== product.id && p.collection !== product.collection
  );
  return [...sameCollection, ...others].slice(0, limit);
}

export const ALL_COLORS: string[] = Array.from(
  new Set(PRODUCTS.flatMap((p) => p.colors.map((c) => c.name)))
).sort();

export const ALL_STYLES: string[] = Array.from(
  new Set(PRODUCTS.map((p) => p.style))
).sort();
