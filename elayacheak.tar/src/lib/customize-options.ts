/**
 * ─────────────────────────────────────────────────────────────
 *  ELAYA — CUSTOMIZATION OPTIONS (sample data)
 *  Administrators can edit styles, colours, add-on prices and
 *  character limits here. Only promise what you can actually
 *  produce — everything shown to customers comes from this file.
 * ─────────────────────────────────────────────────────────────
 */

export interface BagStyle {
  id: string;
  name: string;
  basePrice: number;
  image: string;
  blurb: string;
}

export interface CustomizeColor {
  id: string;
  name: string;
  hex: string;
  priceDelta: number;
}

export interface DecorElement {
  id: string;
  name: string;
  price: number;
  description: string;
}

export interface Accessory {
  id: string;
  name: string;
  price: number;
  description: string;
}

export interface GiftPackaging {
  id: string;
  name: string;
  price: number;
  description: string;
}

export const BAG_STYLES: BagStyle[] = [
  {
    id: "mini-tote",
    name: "Mini Tote",
    basePrice: 2850,
    image: "/images/product-01a.png",
    blurb: "Compact and structured — perfect for essentials-only days.",
  },
  {
    id: "classic-top-handle",
    name: "Classic Top Handle",
    basePrice: 3450,
    image: "/images/product-02a.png",
    blurb: "A refined silhouette for formal and festive occasions.",
  },
  {
    id: "everyday-tote",
    name: "Everyday Tote",
    basePrice: 3250,
    image: "/images/product-03a.png",
    blurb: "Roomy and practical — laptop, notebooks, and life.",
  },
  {
    id: "crossbody",
    name: "Crossbody",
    basePrice: 2950,
    image: "/images/product-06a.png",
    blurb: "Hands-free ease with an adjustable strap.",
  },
  {
    id: "evening-clutch",
    name: "Evening Clutch",
    basePrice: 3150,
    image: "/images/product-05a.png",
    blurb: "Sleek and elegant for dinners and celebrations.",
  },
];

export const CUSTOMIZE_COLORS: CustomizeColor[] = [
  { id: "blush-pink", name: "Blush Pink", hex: "#E8C4BE", priceDelta: 0 },
  { id: "dusty-rose", name: "Dusty Rose", hex: "#D9A6A0", priceDelta: 0 },
  { id: "burgundy", name: "Burgundy", hex: "#682D3B", priceDelta: 0 },
  { id: "cream", name: "Cream", hex: "#F1E7DA", priceDelta: 0 },
  { id: "taupe", name: "Taupe", hex: "#B9A48E", priceDelta: 0 },
  { id: "black", name: "Black", hex: "#2B2626", priceDelta: 100 },
  { id: "sage", name: "Sage", hex: "#A8B5A2", priceDelta: 150 },
];

export const DECOR_ELEMENTS: DecorElement[] = [
  {
    id: "gold-initial-charm",
    name: "Gold Initial Charm",
    price: 250,
    description: "A gold-tone letter charm attached to the handle.",
  },
  {
    id: "tassel",
    name: "Silk Tassel",
    price: 150,
    description: "A soft silk tassel in a matching or contrast shade.",
  },
  {
    id: "pearl-strap-wrap",
    name: "Pearl Strap Wrap",
    price: 350,
    description: "Delicate pearls woven around the strap or handle.",
  },
  {
    id: "bow-detail",
    name: "Satin Bow",
    price: 200,
    description: "A hand-tied satin bow on the front panel.",
  },
  {
    id: "floral-embroidery",
    name: "Floral Embroidery",
    price: 500,
    description: "A small embroidered floral motif of your choice.",
  },
];

export const ACCESSORIES: Accessory[] = [
  {
    id: "dust-bag",
    name: "Branded Dust Bag",
    price: 250,
    description: "Keeps your bag protected when not in use.",
  },
  {
    id: "chain-strap",
    name: "Gold Chain Strap",
    price: 450,
    description: "An attachable gold-tone chain for evening styling.",
  },
  {
    id: "coin-purse",
    name: "Matching Coin Purse",
    price: 350,
    description: "A mini companion purse in your chosen colour.",
  },
];

export const GIFT_PACKAGING: GiftPackaging[] = [
  {
    id: "none",
    name: "No gift packaging",
    price: 0,
    description: "Your bag arrives in standard protective packaging.",
  },
  {
    id: "standard-box",
    name: "Standard Gift Box",
    price: 300,
    description: "Cream gift box with tissue and a plain card.",
  },
  {
    id: "deluxe-box",
    name: "Deluxe Box + Ribbon + Card",
    price: 550,
    description: "Signature box, satin ribbon and a handwritten-style card.",
  },
];

/** Validation limits for personalized text */
export const CUSTOMIZE_LIMITS = {
  initials: { min: 0, max: 12 },
  message: { min: 0, max: 60 },
  messagePrice: 400,
} as const;

export interface CustomizationState {
  styleId: string;
  colorId: string;
  decorIds: string[];
  initials: string;
  message: string;
  accessoryIds: string[];
  giftPackagingId: string;
}

export const DEFAULT_CUSTOMIZATION: CustomizationState = {
  styleId: "mini-tote",
  colorId: "blush-pink",
  decorIds: [],
  initials: "",
  message: "",
  accessoryIds: [],
  giftPackagingId: "none",
};

export interface CustomizationPricing {
  basePrice: number;
  decorTotal: number;
  accessoryTotal: number;
  packagingTotal: number;
  messageTotal: number;
  total: number;
}

export function calculateCustomization(
  state: CustomizationState
): CustomizationPricing {
  const style = BAG_STYLES.find((s) => s.id === state.styleId) ?? BAG_STYLES[0];
  const color =
    CUSTOMIZE_COLORS.find((c) => c.id === state.colorId) ?? CUSTOMIZE_COLORS[0];
  const decorTotal = state.decorIds.reduce(
    (sum, id) => sum + (DECOR_ELEMENTS.find((d) => d.id === id)?.price ?? 0),
    0
  );
  const accessoryTotal = state.accessoryIds.reduce(
    (sum, id) => sum + (ACCESSORIES.find((a) => a.id === id)?.price ?? 0),
    0
  );
  const packagingTotal =
    GIFT_PACKAGING.find((g) => g.id === state.giftPackagingId)?.price ?? 0;
  const messageTotal =
    state.message.trim().length > 0 ? CUSTOMIZE_LIMITS.messagePrice : 0;

  const basePrice = style.basePrice + color.priceDelta;
  const total =
    basePrice +
    decorTotal +
    accessoryTotal +
    packagingTotal +
    messageTotal;

  return {
    basePrice,
    decorTotal,
    accessoryTotal,
    packagingTotal,
    messageTotal,
    total,
  };
}
