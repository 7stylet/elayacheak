/**
 * ─────────────────────────────────────────────────────────────
 *  ELAYA — SITE CONFIGURATION
 *  This is the single place to edit business details.
 *  Replace the placeholder values below with real details
 *  before going live. Nothing else needs to change.
 * ─────────────────────────────────────────────────────────────
 */

export const SITE_CONFIG = {
  brand: "ELAYA",
  tagline: "Carry Your Style. Express Your Story.",
  email: "hello@elaya.pk", // ← placeholder: replace with your support email

  /**
   * WhatsApp number for order-taking, e.g. "923001234567"
   * (country code + number, digits only — NO "+" sign, no spaces).
   * Leave it as an empty string "" to hide WhatsApp ordering buttons.
   */
  whatsappNumber: "",

  /**
   * Instagram profile URL, e.g. "https://instagram.com/elaya.pk".
   * Leave it as an empty string "" to show a clearly-labelled
   * placeholder instead of a dead link.
   */
  instagramUrl: "",

  /** Delivery charges in PKR (flat rate) */
  deliveryFee: 250,

  /** Orders above this subtotal get free delivery (0 disables it) */
  freeDeliveryThreshold: 5000,

  /** Estimated delivery window shown to customers */
  deliveryTime: "3–5 working days",

  /**
   * Bank transfer payment. Set `enabled` to true only when the
   * account details below are real and ready to receive payments.
   */
  bankTransfer: {
    enabled: true,
    bankName: "Your Bank Name", // ← placeholder
    accountTitle: "Your Business Title", // ← placeholder
    accountNumber: "0000 0000 0000 0000", // ← placeholder
  },

  /**
   * Currency label used across the store.
   */
  currency: "PKR",

  /** Copyright line in the footer */
  copyright: "© 2026 ELAYA. All rights reserved.",
} as const;

export function formatPKR(amount: number): string {
  return `Rs ${amount.toLocaleString("en-US")}`;
}

export function whatsappLink(message: string): string {
  if (!SITE_CONFIG.whatsappNumber) return "";
  return `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
