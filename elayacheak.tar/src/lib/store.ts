"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { SITE_CONFIG } from "./config";

/* ────────────────────────── Routing ────────────────────────── */

export type ViewName =
  | "home"
  | "shop"
  | "product"
  | "customize"
  | "cart"
  | "checkout"
  | "order-success"
  | "wishlist"
  | "about"
  | "contact"
  | "faq"
  | "shipping"
  | "returns"
  | "privacy"
  | "terms";

export interface Route {
  view: ViewName;
  slug?: string;
  /** optional query, e.g. preselected collection filter on shop */
  collection?: string;
}

const VIEW_PATHS: Record<ViewName, string> = {
  home: "",
  shop: "shop",
  product: "product",
  customize: "customize",
  cart: "cart",
  checkout: "checkout",
  "order-success": "order-success",
  wishlist: "wishlist",
  about: "about",
  contact: "contact",
  faq: "faq",
  shipping: "shipping",
  returns: "returns",
  privacy: "privacy",
  terms: "terms",
};

export function routeToHash(route: Route): string {
  const base = VIEW_PATHS[route.view];
  if (route.view === "product" && route.slug) return `#/product/${route.slug}`;
  const params = new URLSearchParams();
  if (route.collection) params.set("collection", route.collection);
  const qs = params.toString();
  return `#/${base ? base : ""}${qs ? `?${qs}` : ""}`;
}

export function hashToRoute(hash: string): Route {
  const clean = hash.replace(/^#\/?/, "");
  const [pathPart, queryPart] = clean.split("?");
  const segments = pathPart.split("/").filter(Boolean);
  const params = new URLSearchParams(queryPart ?? "");
  const collection = params.get("collection") ?? undefined;

  if (segments.length === 0) return { view: "home" };
  const [first, second] = segments;
  const known = (Object.keys(VIEW_PATHS) as ViewName[]).find(
    (v) => VIEW_PATHS[v] === first
  );
  if (first === "product" && second) return { view: "product", slug: second };
  if (known) return { view: known, collection };
  return { view: "home" };
}

/* ────────────────────────── Cart ────────────────────────── */

export interface CartCustomization {
  styleName?: string;
  colorName?: string;
  initials?: string;
  message?: string;
  decor: string[];
  accessories: string[];
  packaging?: string;
}

export interface CartItem {
  key: string;
  productId: string;
  name: string;
  image: string;
  unitPrice: number;
  color: string;
  qty: number;
  customization?: CartCustomization;
  isCustom?: boolean;
}

/* ────────────────────────── Store ────────────────────────── */

export interface LastOrder {
  orderNumber: string;
  placedAt: string;
  total: number;
  paymentMethod: string;
  itemCount: number;
}

interface ELAYAState {
  /* routing */
  route: Route;
  navigate: (route: Route) => void;
  replaceRoute: (route: Route) => void;
  syncFromHash: () => void;

  /* cart */
  cart: CartItem[];
  addToCart: (item: Omit<CartItem, "key"> & { key?: string }) => void;
  removeFromCart: (key: string) => void;
  setQty: (key: string, qty: number) => void;
  clearCart: () => void;

  /* wishlist */
  wishlist: string[];
  toggleWishlist: (productId: string) => void;

  /* ui */
  cartOpen: boolean;
  setCartOpen: (v: boolean) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;

  /* orders */
  lastOrder: LastOrder | null;
  setLastOrder: (order: LastOrder | null) => void;
}

export const useELAYA = create<ELAYAState>()(
  persist(
    (set, get) => ({
      route: { view: "home" },

      navigate: (route) => {
        const current = get().route;
        const same =
          current.view === route.view && current.slug === route.slug &&
          current.collection === route.collection;
        set({ route, menuOpen: false, searchOpen: false });
        if (typeof window !== "undefined" && !same) {
          try {
            window.history.pushState({ elaya: true }, "", routeToHash(route));
          } catch {
            /* noop */
          }
        }
        if (typeof window !== "undefined") {
          window.scrollTo({ top: 0, behavior: "auto" });
        }
      },

      replaceRoute: (route) => {
        set({ route, menuOpen: false, searchOpen: false });
        if (typeof window !== "undefined") {
          try {
            window.history.replaceState({ elaya: true }, "", routeToHash(route));
          } catch {
            /* noop */
          }
        }
      },

      syncFromHash: () => {
        if (typeof window === "undefined") return;
        const route = hashToRoute(window.location.hash);
        set({ route });
      },

      cart: [],

      addToCart: (item) => {
        const key =
          item.key ??
          `${item.productId}::${item.color}::${item.customization ? JSON.stringify(item.customization) : "std"}`;
        const existing = get().cart.find((i) => i.key === key);
        if (existing) {
          set({
            cart: get().cart.map((i) =>
              i.key === key ? { ...i, qty: Math.min(9, i.qty + item.qty) } : i
            ),
          });
        } else {
          set({ cart: [...get().cart, { ...item, key, qty: Math.min(9, item.qty) }] });
        }
      },

      removeFromCart: (key) => {
        set({ cart: get().cart.filter((i) => i.key !== key) });
      },

      setQty: (key, qty) => {
        if (qty < 1) {
          set({ cart: get().cart.filter((i) => i.key !== key) });
          return;
        }
        set({
          cart: get().cart.map((i) =>
            i.key === key ? { ...i, qty: Math.min(9, qty) } : i
          ),
        });
      },

      clearCart: () => set({ cart: [] }),

      wishlist: [],

      toggleWishlist: (productId) => {
        const list = get().wishlist;
        set({
          wishlist: list.includes(productId)
            ? list.filter((id) => id !== productId)
            : [...list, productId],
        });
      },

      cartOpen: false,
      setCartOpen: (v) => set({ cartOpen: v }),
      searchOpen: false,
      setSearchOpen: (v) => set({ searchOpen: v }),
      menuOpen: false,
      setMenuOpen: (v) => set({ menuOpen: v }),

      lastOrder: null,
      setLastOrder: (order) => set({ lastOrder: order }),
    }),
    {
      name: "elaya-store-v1",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        cart: state.cart,
        wishlist: state.wishlist,
        lastOrder: state.lastOrder,
      }),
    }
  )
);

/* ─────────────────────── Derived helpers ─────────────────────── */

export function cartSubtotal(cart: CartItem[]): number {
  return cart.reduce((sum, item) => sum + item.unitPrice * item.qty, 0);
}

export function cartCount(cart: CartItem[]): number {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

export function deliveryFeeFor(subtotal: number): number {
  if (SITE_CONFIG.freeDeliveryThreshold > 0 && subtotal >= SITE_CONFIG.freeDeliveryThreshold)
    return 0;
  return SITE_CONFIG.deliveryFee;
}
