/**
 * Convenience re-exports so components can pull everything
 * product-related from a single module.
 */
export * from "./products";
export { formatPKR as formatPKRDisplay, formatPKR, SITE_CONFIG } from "./config";
